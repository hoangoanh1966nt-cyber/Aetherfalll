from pathlib import Path
import json, uuid, shutil, re
ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'data/game_data_0_6.json').read_text(encoding='utf-8'))
source=(ROOT/'scripts/runtime_event.js.in').read_text(encoding='utf-8')
script=source.replace('__AETHERFALL_DATA__', json.dumps(DATA,ensure_ascii=False,separators=(',',':')))
(ROOT/'scripts/runtime_event.js').write_text(script,encoding='utf-8')

# Project resources.
resources=[]
for path in sorted((ROOT/'assets').rglob('*.png')):
    rel=path.relative_to(ROOT).as_posix()
    resources.append({"alwaysLoaded": False, "file": rel, "kind": "image", "metadata": "", "name": rel, "smoothed": False, "userAdded": True})

# Sprite objects use cropped per-frame PNGs: 4 animations x 6 frames.
def sprite_frame(image, cell):
    half=cell/2
    return {"hasCustomCollisionMask":False,"image":image,"points":[],"originPoint":{"name":"origine","x":half,"y":cell-5},"centerPoint":{"automatic":True,"name":"centre","x":half,"y":half},"customCollisionMask":[]}

def make_animated_sprite(obj_name, asset_name, cell=48):
    animations=[]
    for anim_name in ['idle','move','telegraph','attack']:
        sprites=[]
        for idx in range(1,7):
            fn=f'assets/sprites/{asset_name}_{anim_name}_{idx}.png'
            if (ROOT/fn).exists(): sprites.append(sprite_frame(fn,cell))
        if not sprites:
            fn=f'assets/sprites/{asset_name}.png'
            sprites=[sprite_frame(fn,cell)]
        animations.append({"name":anim_name.title(),"useMultipleDirections":False,"directions":[{"looping":anim_name!='telegraph' and anim_name!='attack',"timeBetweenFrames":0.13 if anim_name=='move' else 0.2,"sprites":sprites}]})
    return {"name":obj_name,"tags":"","type":"Sprite","updateIfNotVisible":False,"variables":[],"behaviors":[],"animations":animations}

def make_static_sprite(obj_name, image, w=None, h=None):
    im=ROOT/image
    if im.exists():
        from PIL import Image
        iw,ih=Image.open(im).size
    else: iw,ih=32,32
    fr={"hasCustomCollisionMask":False,"image":image,"points":[],"originPoint":{"name":"origine","x":0,"y":0},"centerPoint":{"automatic":True,"name":"centre","x":iw/2,"y":ih/2},"customCollisionMask":[]}
    return {"name":obj_name,"tags":"","type":"Sprite","updateIfNotVisible":False,"variables":[],"behaviors":[],"animations":[{"name":"","useMultipleDirections":False,"directions":[{"looping":False,"timeBetweenFrames":1,"sprites":[fr]}]}]}

objects=[]
objects.append({"bold":False,"italic":False,"name":"UiText","smoothed":False,"tags":"","type":"TextObject::Text","underlined":False,"variables":[],"behaviors":[],"string":"","font":"","characterSize":18,"color":{"b":210,"g":229,"r":238}})
objects.append(make_static_sprite('UiPanel','assets/ui/button_panel.png'))
objects.append(make_animated_sprite('HeroSprite','hero',48))
for class_id in DATA.get('classes',{}):
    objects.append(make_animated_sprite('Hero_'+class_id,'hero_'+class_id,48))
asset_map={
    'moss_goblin':'moss_goblin','forest_brute':'forest_brute','moss_shaman':'moss_shaman','thorn_stalker':'thorn_stalker',
    'moon_wisp':'moon_wisp','bog_lurker':'bog_lurker','void_crawler':'void_crawler','drowned_sentinel':'drowned_sentinel','ancient_grove_warden':'warden',
    'frost_howler':'frost_howler','crystal_guardian':'crystal_guardian',
    'ember_hound':'ember_hound','cinder_mage':'cinder_mage','ash_golem':'ash_golem',
    'star_reaver':'star_reaver','astral_seraph':'astral_seraph',
    'glacier_colossus':'glacier_colossus','ember_drake':'ember_drake','astral_archon':'astral_archon',
    'desecrated_demon':'ash_golem','exiled_king':'warden','skeleton_king':'astral_archon','glacial_swine':'glacier_colossus','infernax':'ember_drake','mutant_rat':'bog_lurker','ashen_reaper':'astral_archon'
}
for enemy_id,asset in asset_map.items():
    obj='Enemy_'+enemy_id if enemy_id!='ancient_grove_warden' else 'Enemy_warden'
    objects.append(make_animated_sprite(obj,asset,64 if asset in ('warden','glacier_colossus','ember_drake','astral_archon') else 48))
# Backdrop sprites for each region.
for theme in sorted({region['theme'] for region in DATA['regions']} | set(DATA.get('menu_themes',[]))):
    objects.append(make_static_sprite('Bg_'+theme,f"assets/backgrounds/{theme}.png"))
# Selected equipment icons.
for slot,asset in [('weapon','sword'),('armor','armor'),('ring','ring')]:
    objects.append(make_static_sprite('Icon_'+slot,f'assets/icons/{asset}.png'))

# Depth-based parallax layers for the gameplay camera.
for theme in sorted({region['theme'] for region in DATA['regions']}):
    for layer in ['far','mid','front']:
        objects.append(make_static_sprite('Bg'+layer.title()+'_'+theme,f"assets/parallax/{theme}_{layer}.png"))
# Lightweight UI meters and pooled enemy projectile visual.
objects.append(make_static_sprite('HudBarBg','assets/ui/hud_bar_bg.png'))
objects.append(make_static_sprite('HudHpFill','assets/ui/hud_hp_fill.png'))
objects.append(make_static_sprite('HudMpFill','assets/ui/hud_mp_fill.png'))
objects.append(make_static_sprite('HudBossFill','assets/ui/hud_boss_fill.png'))
objects.append(make_static_sprite('EnemyBolt','assets/vfx/enemy_bolt.png'))

extensions=[
    "BuiltinObject","BuiltinAudio","BuiltinVariables","BuiltinTime","BuiltinMouse","BuiltinKeyboard","BuiltinJoystick","BuiltinCamera","BuiltinWindow","BuiltinFile","BuiltinNetwork","BuiltinScene","BuiltinAdvanced","Sprite","TextObject","BuiltinCommonInstructions","BuiltinCommonConversions","BuiltinStringInstructions","BuiltinMathematicalTools","BuiltinExternalLayouts"
]
js_event={"disabled":False,"folded":False,"type":"BuiltinCommonInstructions::JsCode","inlineCode":script,"parameterObjects":"","useStrict":True,"eventsSheetExpanded":True}
layout={
    "b":20,"disableInputWhenNotFocused":True,"mangledName":"Main","name":"Main","oglFOV":90,"oglZFar":500,"oglZNear":1,
    "r":13,"standardSortMethod":True,"stopSoundsOnStartup":True,"title":"Aetherfall: Echoes of the Wild",
    "v":17,"uiSettings":{"grid":False,"gridB":255,"gridG":180,"gridHeight":32,"gridOffsetX":0,"gridOffsetY":0,"gridR":158,"gridWidth":32,"snap":True,"windowMask":False,"zoomFactor":1},
    "objectsGroups":[],"variables":[],"instances":[],"objects":[],"events":[js_event],
    "layers":[{"ambientLightColorB":255,"ambientLightColorG":255,"ambientLightColorR":255,"followBaseLayerCamera":False,"isLightingLayer":False,"name":"","visibility":True,"cameras":[{"defaultSize":True,"defaultViewport":True,"height":0,"viewportBottom":1,"viewportLeft":0,"viewportRight":1,"viewportTop":0,"width":0}],"effects":[]}],
    "behaviorsSharedData":[]
}
project={
    "firstLayout":"Main",
    "gdVersion":{"build":0,"major":5,"minor":5,"revision":0},
    "properties":{
        "adaptGameResolutionAtRuntime":True,"folderProject":False,"orientation":"landscape","packageName":"com.aetherfall.echoeswild",
        "projectUuid":str(uuid.uuid4()),"scaleMode":"nearest","sizeOnStartupMode":"","useDeprecatedZeroAsDefaultZOrder":True,"useExternalSourceFiles":False,
        "version":DATA['game']['version'],"name":"Aetherfall: Echoes of the Wild","description":"2D pixel action RPG offline with deep character progression.","author":"Aetherfall Project","publisherName":"Aetherfall Project",
        "windowWidth":960,"windowHeight":540,"maxFPS":60,"minFPS":20,"verticalSync":False,"platformSpecificAssets":{},
        "loadingScreen":{"showGDevelopSplash":True},"extensionProperties":[],"extensions":[{"name":x} for x in extensions],
        "platforms":[{"name":"GDevelop JS platform"}],"currentPlatform":"GDevelop JS platform"
    },
    "resources":{"resources":resources,"resourceFolders":[]},
    "objects":objects,"objectsGroups":[],"variables":[],"layouts":[layout],"externalEvents":[],"eventsFunctionsExtensions":[],"externalLayouts":[],"externalSourceFiles":[]
}
(ROOT/'game.json').write_text(json.dumps(project,ensure_ascii=False,indent=2),encoding='utf-8')
print('Project generated:',ROOT/'game.json')
print('Objects:',len(objects),'Resources:',len(resources),'Event code:',len(script),'chars')
