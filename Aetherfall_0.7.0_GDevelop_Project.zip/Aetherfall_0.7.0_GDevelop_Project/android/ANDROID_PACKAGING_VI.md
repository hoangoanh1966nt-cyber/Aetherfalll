# Hướng dẫn xuất Android — Aetherfall 0.7.0

## A. Cấu hình project

Trong GDevelop Project Manager → Project Properties, xác nhận:

- App name: `Aetherfall: Echoes of the Wild`
- Package ID: `com.aetherfall.echoeswild`
- Version: `0.7.0`
- Orientation: Landscape
- Resolution tham chiếu: 960×540; scale mode nearest-neighbour.
- App icon: `assets/app_icon.png`.
- First layout: `Main`.

Chạy Preview trước khi đóng gói. Kiểm tra màn chọn hồ sơ, lobby, chọn nghề, 4 trang bản đồ, 4 nghề và một lượt chơi map dài.

## B. Xuất APK bằng GDevelop One-click packaging

1. Mở `game.json` trong GDevelop Editor.
2. Chọn **Share → Android → One-click packaging**.
3. Chọn **APK** cho bản cài thử trên điện thoại; chọn **AAB** khi chuẩn bị phát hành Google Play.
4. Kiểm tra package ID, phiên bản, tên app, icon và hướng ngang.
5. Chọn **Package for Android**, đợi Cloud Build hoàn tất rồi tải artifact từ GDevelop.
6. Cài APK trên Android thật và chạy checklist ở cuối tài liệu.

Quyền Cloud Build/hạn mức xuất phụ thuộc tài khoản và gói GDevelop hiện hành. Đối chiếu hướng dẫn mới nhất: https://wiki.gdevelop.io/gdevelop5/publishing/android_and_ios/

## C. Xuất thủ công bằng Cordova (nâng cao)

1. Trong GDevelop, chọn **Share → Manual export → Android / Cordova**.
2. Cài Node.js/npm, Java JDK, Android SDK/Build Tools, Gradle và Cordova theo đúng phiên bản được GDevelop export.
3. Chạy `cordova requirements android` để kiểm tra môi trường, sau đó `cordova build android`.
4. Với release, tạo keystore riêng và giữ bí mật. Không đưa keystore/password vào ZIP hoặc source control.
5. Cài APK lên Android thật và kiểm tra.

## D. Checklist Android 0.7.0

- [ ] App cài mới và mở vào màn hình chọn hồ sơ.
- [ ] VN-01/VN-02/AS-01 độc lập; save tồn tại sau khi tắt/mở lại.
- [ ] Chọn/đổi được Warrior, Mage, Archer và Rogue; đòn đánh, tầm đánh và kỹ năng tác động thực tế.
- [ ] 31 địa điểm hiển thị theo 4 trang; gate campaign/event/challenge đúng cấu hình.
- [ ] Chơi được map dài, nền parallax phủ hết chiều ngang; quái/boss đặt dọc map.
- [ ] Tower of Insanity spawn Mutant Rat và Ashen Reaper.
- [ ] EXP Lv.36 = 70.000; quái/boss theo cấp map cho EXP khác nhau.
- [ ] Đánh quái, loot, vàng và boss không crash khi đổi vùng.
- [ ] Inventory mở được; trang bị dưới required level bị chặn; cường hóa không quá +20.
- [ ] Nhiệm vụ không nhận thưởng hai lần; potion/food/buff và cooldown đúng.
- [ ] Oxy/checkpoint/respawn an toàn hoạt động.
- [ ] Kiểm tra màn hình 16:9/20:9, notch/safe area, touch đa điểm và orientation ngang.
- [ ] Chạy phiên chơi đủ dài và đo FPS/RAM/nhiệt độ/pin; không crash/rò bộ nhớ.
- [ ] APK cài được và mở được từ icon app.

## E. Trạng thái hiện tại

Aetherfall 0.7.0 đã qua **42 kiểm tra cấu trúc tĩnh**, Node syntax check, và mock-runtime tests. Tuy nhiên, trong lần bàn giao này **chưa mở GDevelop Editor Preview, chưa xuất APK/AAB, chưa ký và chưa cài lên Android**. Không đánh dấu các mục checklist trên là PASS cho tới khi chạy trên thiết bị thật.
