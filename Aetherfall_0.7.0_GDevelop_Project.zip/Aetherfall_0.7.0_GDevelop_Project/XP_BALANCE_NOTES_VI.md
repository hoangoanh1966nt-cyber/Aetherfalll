# Aetherfall 0.7.0 — Cân bằng EXP 1–200

## Mốc đã hiệu chỉnh
- Lv.1 → 2: **336 EXP**.
- Lv.36 → 37: **70.000 EXP** (mốc gần đúng theo thông tin người chơi xác nhận “70 mấy”).
- Lv.138 → 139: **10.500.000 EXP** (mốc quan sát từ ảnh túi đồ trước đó; chưa xác định được chính xác phiên bản Darkrise).
- Tổng EXP yêu cầu để đi từ Lv.1 lên Lv.180: **2.000.000.000 EXP**.
- Tổng EXP yêu cầu riêng từ Lv.190 lên Lv.200: **5.000.000.000 EXP**.
- Darkrise v0.26 ghi giảm 50% EXP yêu cầu ở dải Lv.130–200 so với đường cong trước bản vá. Đây **không** có nghĩa Lv.130 chỉ cần bằng một nửa Lv.129. Bảng Aetherfall hiện giữ ngưỡng tăng đều: Lv.129 = **6.500.000**, Lv.130 = **6.700.000**, Lv.138 = **10.500.000**.

## Một số mốc trong bảng Aetherfall
| Cấp hiện tại | EXP cần để lên cấp tiếp | Ghi chú |
|---:|---:|---|
| 1 | 336 | Đầu game |
| 5 | 618 | Đầu game |
| 10 | 1.326 | Đầu game |
| 20 | 6.091 | Giữa đầu game |
| 30 | 27.990 | Tăng dần |
| 35 | 60.000 | Trước mốc Lv.36 |
| 36 | 70.000 | Mốc người chơi xác nhận gần đúng |
| 37 | 73.495 | Sau mốc Lv.36 |
| 45 | 108.525 | Tiến trình map tầm trung |
| 56 | 185.474 | Tiến trình map tầm trung |
| 80 | 597.183 | Mốc Elmort Catacombs tham chiếu |
| 100 | 1.582.317 | Cuối giai đoạn trung cấp |
| 120 | 4.192.563 | Trước dải cấp cao |
| 129 | 6.500.000 | Trước dải cấp cao |
| 130 | 6.700.000 | Tiếp tục tăng so với Lv.129 |
| 131 | 7.087.027 | Đường cong tăng đều |
| 132 | 7.496.412 | Đường cong tăng đều |
| 133 | 7.929.444 | Đường cong tăng đều |
| 134 | 8.387.491 | Đường cong tăng đều |
| 135 | 8.871.997 | Đường cong tăng đều |
| 136 | 9.384.490 | Đường cong tăng đều |
| 137 | 9.926.588 | Đường cong tăng đều |
| 138 | 10.500.000 | Mốc quan sát tạm tính |
| 155 | 28.005.456 | Snowdale tham chiếu |
| 170 | 66.553.678 | Lava's Edge tham chiếu |
| 180 | 122.369.841 | Bridge / late game |
| 190 | 300.000.000 | Đầu đoạn 190–200 |
| 199 | 763.137.920 | Cấp cuối trước Lv.200 |
| 200 | 0 | Đạt cấp tối đa |

## Cách tính EXP quái và boss
1. EXP lên cấp là bảng 200 giá trị được lưu cố định trong `data/game_data_0_6.json`.
2. Mỗi cấp có một map khuyến nghị và số lượt hạ quái mục tiêu.
3. EXP quái thường được hiệu chuẩn theo EXP cần lên cấp, trung bình EXP gốc trong roster map và số lượt hạ quái mục tiêu.
4. Giữ khác biệt giữa từng loại quái trong cùng map; boss nhận hệ số theo EXP gốc riêng của boss, không phải mọi boss đều chung một con số.
5. Khi người chơi vượt quá cấp phù hợp của map cũ, phần thưởng sẽ giảm theo hệ số chống farm map quá thấp.

## Nguồn và độ tin cậy
- Game gốc không công bố bảng EXP chi tiết từng cấp trong tài liệu tham khảo hiện có.
- Mốc 70.000 ở Lv.36 do người chơi cung cấp dưới dạng ước lượng “70 mấy”; Aetherfall dùng 70.000 làm neo thực hành, không tuyên bố đây là số đo chính xác của Darkrise.
- Mốc 10,5 triệu ở Lv.138 là quan sát giao diện cũ, chưa xác minh bản game/độ khó.
- Tổng 2B đến Lv.180 và 5B cho Lv.190–200 là lời kể cộng đồng, không phải bảng official.
- Cập nhật Darkrise v0.26 được ghi nhận có điều chỉnh giảm một nửa EXP yêu cầu ở dải Lv.130–200 so với bảng trước bản vá; không có bảng pre/post đầy đủ để so sánh từng cấp. Vì vậy không lấy Lv.129 làm mốc chia đôi cho Lv.130.
- Vì thế, bảng này là **đường cong cân bằng Aetherfall lấy Darkrise làm tham chiếu**, không phải dữ liệu nội bộ hoặc bảng chính thức Darkrise.

Bảng đầy đủ: `docs/XP_CURVE_0.7.0.csv`.
