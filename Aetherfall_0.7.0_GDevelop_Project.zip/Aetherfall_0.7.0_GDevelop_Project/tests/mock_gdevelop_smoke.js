const fs = require('fs');
const path = require('path');
const code = fs.readFileSync(path.join(__dirname, '../scripts/runtime_event.js'), 'utf8');
const match = code.match(/^const DATA = (.*);$/m);
if (!match) throw new Error('Embedded game data not found');
const DATA = JSON.parse(match[1]);
const expose = code.replace(
  '  const frameNow=Date.now();',
  '  globalThis.__AETHERFALL_TEST_HOOKS={moveEnemyAI,updateEnemyProjectiles,launchEnemyBolt,xpNeed,enemyXp,questXp,rewardEnemy,applyLevelUps,canEnterRegion,spawnEnemies,equipSelected,upgradeSelected,sellSelected,selectedItem,migrateProfile,effectiveStats,enterRegion,freshProfile,playerAttack};\n  const frameNow=Date.now();'
);
class Obj {
  constructor(name){this.name=name;this.text='';this.x=0;this.y=0;this.opacity=255;this.dead=false;this.vars={};}
  setText(v){this.text=String(v);} setString(v){this.text=String(v);} setPosition(x,y){this.x=x;this.y=y;}
  setCharacterSize(v){this.size=v;} setColor(v){this.color=v;} setWrapping(v){this.wrap=v;} setWrappingWidth(v){this.wrapWidth=v;}
  setBold(v){this.bold=v;} setZOrder(v){this.z=v;} setSize(w,h){this.width=w;this.height=h;} setOpacity(v){this.opacity=v;}
  setAnimationIndex(v){this.animation=v;} setScale(v){this.scale=v;} flipX(v){this.flipped=v;} deleteFromScene(){this.dead=true;}
}
class Input {
  constructor(){this.down=false;this.x=0;this.y=0;this.keys=new Set();}
  isMouseButtonPressed(n){return n===0&&this.down;} getCursorX(){return this.x;} getCursorY(){return this.y;}
  getAllTouchIdentifiers(){return [];} getTouchX(){return 0;} getTouchY(){return 0;}
  isKeyPressed(k){return this.keys.has(k);} set(x,y,down){this.x=x;this.y=y;this.down=down;}
}
const input=new Input();
const scene={created:[],createObject(name){const o=new Obj(name);this.created.push(o);return o;},getGame(){return {getInputManager(){return input;}};}};
const sandbox={runtimeScene:scene,console,Math,Date,JSON,Object,Array,Number,String,Boolean,Set,Map,globalThis:null,localStorage:{_m:new Map(),getItem(k){return this._m.get(k)||null;},setItem(k,v){this._m.set(k,String(v));},removeItem(k){this._m.delete(k);}}};
sandbox.globalThis=sandbox;
const event=new Function('runtimeScene','globalThis','localStorage','console','Date','Math',expose);
const run=()=>event(scene,sandbox,sandbox.localStorage,console,Date,Math);
const click=(x,y)=>{input.set(x,y,false);run();input.set(x,y,true);run();input.set(x,y,false);run();};
const assert=(ok,msg)=>{if(!ok)throw new Error(msg);};

// Boot and basic profile selection.
sandbox.localStorage.setItem('aetherfall_profile_VN-02',JSON.stringify({schemaVersion:8,level:138,xp:47922,gold:321,classId:'rogue',inventory:[],equipped:{}}));
run();
let C=sandbox.__AETHERFALL_RUNTIME;
assert(C.page==='servers','Initial page should be profile selection.');
assert(C.uiPool.some(o=>o&&o.text.includes('VN-01')),'Profile buttons should render.');
click(300,322);
assert(C.page==='lobby'&&C.server==='VN-01','Selecting the first profile should open the lobby.');
assert(C.profile.schemaVersion===9&&C.profile.classId==='warrior','Fresh profile should use schema 9 and Warrior by default.');
assert(C.uiPool.some(o=>o&&o.text.includes('31 địa điểm')&&o.text.includes('4 nghề')),'Lobby should advertise the expanded map/class scope.');

// Class selection: each of the four Darkrise-inspired archetypes must exist, render and have independent stat/skill kits.
const classes=DATA.classes;
assert(['warrior','mage','archer','rogue'].every(k=>classes[k]),'Four classes Warrior/Mage/Archer/Rogue must be present.');
for(const [id,c] of Object.entries(classes)){
  assert(c.basic_attack&&c.skills&&Object.keys(c.skills).length===3,`${id} must have a basic attack and three skills.`);
  assert(c.stats&&Number.isFinite(c.stats.hp)&&Number.isFinite(c.stats.atk),`${id} must define class stats.`);
}
assert(new Set(Object.values(classes).map(c=>JSON.stringify(c.skills))).size===4,'Each class must have a distinct skill set.');
C.page='classes';run();
for(const c of Object.values(classes))assert(C.uiPool.some(o=>o&&o.text.includes(c.name)),`Class screen should render ${c.name}.`);
C.profile.classId='mage';
const mageStats=sandbox.__AETHERFALL_TEST_HOOKS.effectiveStats(C.profile);
C.profile.classId='warrior';
const warriorStats=sandbox.__AETHERFALL_TEST_HOOKS.effectiveStats(C.profile);
assert(mageStats.attackRange!==warriorStats.attackRange||mageStats.attackDamage!==warriorStats.attackDamage,'Class choice must change actual combat stats.');

// Verify all known Darkrise places are represented, each with a substantial map run and map-specific theme.
const expectedNames=['Slime Field','Meadow','Hidden Cave',"Golem's Valley",'Frost Hill',"Mayor's Farm","Criminals' Hideout",'Snowy Field','Northern Outpost','Bat Cave','Thieves Den','Dark Thickets','Crossroads','Western Way','Povzevo','Dawnstall','Elmort Catacombs','Desecrated Field','Ancient Fortress','Lost Souls Graveyard','Snowdale','Forgotten Hillside',"Lava's Edge",'Abandoned Woods','Bridge of Stagnation','Tower of Insanity','Forest of Wished','Moonlit Forest',"Moonlit Forest's Edge",'Starlit Marsh','Enchanted Swamp'];
assert(DATA.regions.length===31,'The known-location catalog should contain 31 entries, not the old 8-region set.');
for(const name of expectedNames)assert(DATA.regions.some(r=>r.name===name),`Missing original Darkrise place name: ${name}.`);
for(const r of DATA.regions){
  assert(r.length>=7500,`${r.name} should be a long side-scrolling map.`);
  assert(Array.isArray(r.segments)&&r.segments.length>=5,`${r.name} should define multiple route sections.`);
  assert(r.theme&&DATA.regions.filter(x=>x.theme===r.theme).length===1,`${r.name} should have its own map theme.`);
  assert(r.reference_note&&r.source_confidence,`${r.name} should identify its reference confidence.`);
}
assert(DATA.settlements.some(x=>x.name==='Krosstoen')&&DATA.settlements.some(x=>x.name==='Hill Town')&&DATA.settlements.some(x=>x.name==='Elmort'),'Krosstoen, Hill Town and Elmort should be represented as settlements.');
assert(DATA.map_reference.known_locations===31,'Project should record that 31 researched locations are presently catalogued.');
assert(DATA.map_reference.total_locations_darkrise_store_description_approx>=100,'Project must disclose that the store describes about 100 locations overall.');

// Gates: campaign progression is sequential, event/challenge access uses the map's own level gate, reward room follows Bridge.
const hooks=sandbox.__AETHERFALL_TEST_HOOKS;
let p=hooks.freshProfile();
assert(hooks.canEnterRegion(p,0).ok,'Slime Field should be available from the start.');
assert(!hooks.canEnterRegion(p,1).ok,'Meadow should remain gated until level and previous map progress are met.');
p.level=DATA.regions[1].min_level;
assert(!hooks.canEnterRegion(p,1).ok,'Meadow should still require completion of Slime Field.');
p.clearedStages=[0];
assert(hooks.canEnterRegion(p,1).ok,'Meadow should unlock after its level and progression gates are met.');
p.level=20;p.clearedStages=[];
assert(hooks.canEnterRegion(p,27).ok,'Moonlit Forest event map should use its own entry gate, not campaign sequence.');
p.level=85;
assert(hooks.canEnterRegion(p,30).ok,'Enchanted Swamp challenge should unlock at its configured level.');
assert(!hooks.canEnterRegion(p,26).ok,'Forest of Wished should remain locked before Bridge of Stagnation.');
p.level=180;p.clearedStages=[24];
assert(hooks.canEnterRegion(p,26).ok,'Forest of Wished should unlock after Bridge of Stagnation.');

// Long-map enemy placement and the two Tower of Insanity bosses.
for(const index of [0,9,16,20,24,25,27,30]){
  const enemies=hooks.spawnEnemies(index),region=DATA.regions[index];
  assert(enemies.length>=region.enemy_count,`${region.name} should spawn the planned enemy group.`);
  const normal=enemies.filter(e=>!e.boss);
  assert(normal.length>=14,`${region.name} should populate a long route with multiple normal enemies.`);
  const spread=normal[normal.length-1].x-normal[0].x;
  assert(spread>region.length*.55,`${region.name} enemies should occupy most of its side-scrolling length.`);
}
const tower=hooks.spawnEnemies(25).filter(e=>e.boss);
assert(tower.length===2&&tower.some(e=>e.kind==='mutant_rat')&&tower.some(e=>e.kind==='ashen_reaper'),'Tower of Insanity must spawn Mutant Rat and Ashen Reaper.');
assert(hooks.spawnEnemies(18).some(e=>e.boss&&e.kind==='exiled_king'),'Ancient Fortress should spawn Exiled King.');
assert(hooks.spawnEnemies(19).some(e=>e.boss&&e.kind==='skeleton_king'),'Lost Souls Graveyard should spawn Skeleton King.');
assert(hooks.spawnEnemies(21).some(e=>e.boss&&e.kind==='glacial_swine'),'Forgotten Hillside should spawn Glacial Swine.');
assert(hooks.spawnEnemies(22).some(e=>e.boss&&e.kind==='infernax'),'Lava\'s Edge should spawn Infernax.');

// EXP curve: calibrated anchor at Lv.36 (~70k), high-level observation and aggregate community estimates.
const xp=DATA.progression.xp_required_by_level;
assert(xp.length===200,'A full 1–200 XP threshold table must exist.');
assert(hooks.xpNeed(1)===336,'Starting-level EXP anchor should remain 336.');
assert(hooks.xpNeed(36)===70000,'Lv.36 should require about 70,000 EXP.');
assert(hooks.xpNeed(138)===10500000,'Lv.138 should match the provisional ~10.5M observation.');
assert(xp.slice(0,179).reduce((a,b)=>a+b,0)===2000000000,'Requirements from Lv.1 to Lv.180 should total 2B.');
assert(xp.slice(189,199).reduce((a,b)=>a+b,0)===5000000000,'Requirements from Lv.190 to Lv.200 should total 5B.');
assert(hooks.xpNeed(130)>hooks.xpNeed(129),'EXP must remain monotonic across the Lv.129/130 boundary.');
assert(String(DATA.progression.xp_curve_metadata.high_level_patch_context||'').includes('not a claim'),'The 50% patch note must not be misread as half of Lv.129.');
for(let lv=2;lv<=199;lv++)assert(hooks.xpNeed(lv)>hooks.xpNeed(lv-1),`XP thresholds should rise through Lv.${lv}.`);
assert(hooks.xpNeed(200)===0,'Level 200 should not request EXP for another level.');
assert(DATA.progression.xp_target_kills_by_level.length===200,'Map kill pacing should cover every level.');
assert(DATA.progression.xp_map_index_by_level.length===200,'Each level should have a recommended farming map.');
assert(DATA.progression.xp_migration_tables.schema8.length===200,'Schema-8 EXP values should be retained for save migration.');
const oldNeed=DATA.progression.xp_migration_tables.schema8[137];
const migrated=hooks.migrateProfile({schemaVersion:8,level:138,xp:Math.floor(oldNeed/2),classId:'rogue',gold:321});
assert(migrated.level===138&&migrated.xp===5250000,'Schema-8 migration should preserve EXP-bar percentage.');
assert(migrated.classId==='rogue','Save migration should preserve the selected class.');
const baseXp=hooks.enemyXp({kind:DATA.regions[0].enemies[0]},0,{level:1});
const map9Xp=hooks.enemyXp({kind:DATA.regions[9].enemies[0]},9,{level:36});
assert(map9Xp>baseXp,'A later appropriate map should reward more absolute EXP than the starting map.');
const bossXp=hooks.enemyXp({kind:'exiled_king',boss:true},18,{level:125});
const normalXp=hooks.enemyXp({kind:DATA.regions[18].enemies[0]},18,{level:125});
assert(bossXp>normalXp,'Named boss should award more EXP than a regular mob.');
console.log('PASS: 200-level XP anchors, aggregate targets, map-specific and boss EXP, schema-8 migration.');

// Start a real level and verify runtime state, enemy placements, and class selection UI route.
C.page='lobby';C.profile=hooks.freshProfile();C.profile.level=1;C.profile.clearedStages=[];C.page='regionmap';C.selectedRegion=0;run();
assert(C.uiPool.some(o=>o&&o.text.includes('Slime Field')),'First map page should show original map names.');
click(450,450);assert(C.regionPage===1,'Map browser next button should move to page 2.');run();
assert(C.uiPool.some(o=>o&&o.text.includes('Bat Cave')),'Page 2 should show later map names.');
C.page='lobby';run();click(345,451);assert(C.page==='classes','Lobby class button should open the class selection screen.');
C.profile.classId='archer';C.page='lobby';
assert(hooks.enterRegion(0),'The first map should launch from the lobby state.');
assert(C.page==='game'&&C.region===0&&C.enemies.length>=16,'Launching a map should create a populated gameplay session.');
assert(C.bgName===DATA.regions[0].theme,'Entering a map should load its own atmosphere theme.');
// Basic attack reach is genuinely class-specific in the runtime, not only a label in the menu.
C.profile.level=100;C.profile.atk=100;C.profile.mp=100;C.player.x=100;C.player.facing=1;C.player.attackCd=0;
const dummy={kind:DATA.regions[0].enemies[0],x:390,hp:100000,maxHp:100000,dead:false,hitFlash:0};
C.enemies=[dummy];C.profile.classId='warrior';hooks.playerAttack('basic_attack');assert(dummy.hp===100000,'Warrior basic melee range should not hit a far target.');
C.profile.classId='mage';C.player.attackCd=0;hooks.playerAttack('basic_attack');assert(dummy.hp<100000,'Mage basic magic reach should hit beyond Warrior melee range.');
const mageDamage=100000-dummy.hp;dummy.hp=100000;C.profile.classId='archer';C.player.attackCd=0;hooks.playerAttack('basic_attack');assert(100000-dummy.hp>0,'Archer should also hit the long-range target.');
assert(DATA.classes.archer.basic_attack.range>DATA.classes.mage.basic_attack.range,'Archer should have a longer basic-attack reach than Mage.');
console.log('PASS: startup, paged 31-location browser, class navigation, long map entry and class-specific attack reach.');
