#!/usr/bin/env python3
"""Regenerate Aetherfall 0.4 layered pixel backgrounds and HUD/VFX assets."""
from pathlib import Path
import random, math
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[1]
BG = {
 'whisper_forest': {
  'sky':((8,20,29),(22,48,46)), 'far':(23,65,56), 'mid':(17,49,43), 'front':(10,31,28), 'light':(112,180,129), 'accent':(70,132,90), 'kind':'forest'},
 'moss_ruins': {
  'sky':((14,23,34),(47,57,57)), 'far':(54,75,72), 'mid':(45,61,55), 'front':(26,39,37), 'light':(186,157,95), 'accent':(113,133,105), 'kind':'ruins'},
 'moon_marsh': {
  'sky':((6,25,37),(20,62,67)), 'far':(29,88,91), 'mid':(21,66,70), 'front':(9,38,45), 'light':(116,207,203), 'accent':(62,145,137), 'kind':'marsh'},
 'void_roots': {
  'sky':((13,13,30),(45,25,65)), 'far':(58,43,86), 'mid':(44,30,73), 'front':(20,14,38), 'light':(174,107,220), 'accent':(104,61,153), 'kind':'void'},
 'ancient_sanctum': {
  'sky':((28,18,31),(83,46,43)), 'far':(105,66,49), 'mid':(75,48,43), 'front':(36,27,31), 'light':(236,174,93), 'accent':(160,104,61), 'kind':'sanctum'},
 'frozen_wastes': {
  'sky':((7,20,43),(29,68,104)), 'far':(55,99,139), 'mid':(39,78,117), 'front':(13,34,58), 'light':(175,232,255), 'accent':(102,177,217), 'kind':'ice'},
 'ashen_caldera': {
  'sky':((34,12,13),(91,34,21)), 'far':(111,48,31), 'mid':(79,35,28), 'front':(36,17,17), 'light':(255,133,55), 'accent':(187,73,35), 'kind':'fire'},
 'fallen_astral_spire': {
  'sky':((10,8,35),(48,28,85)), 'far':(67,54,119), 'mid':(53,39,100), 'front':(21,15,48), 'light':(207,175,255), 'accent':(131,101,202), 'kind':'astral'},
}

def shade(c, k): return tuple(max(0,min(255,int(v*k))) for v in c)
def create_layers(theme, pal, seed):
    rng=random.Random(seed)
    W,H=960,270
    # FAR: sky gradient, moon/sun glow, distant mountain and tree silhouettes.
    far=Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(far)
    top,bottom=pal['sky']
    for y in range(H):
        t=y/(H-1); col=tuple(int(top[i]*(1-t)+bottom[i]*t) for i in range(3))
        d.line((0,y,W,y), fill=col+(255,))
    light=pal['light']
    cx=rng.randint(210,760); cy=rng.randint(42,104); rad=rng.randint(22,36)
    for rr in range(rad*3,rad,-4):
        alpha=max(5,28-int((rr-rad)*.4))
        d.ellipse((cx-rr,cy-rr,cx+rr,cy+rr),fill=light+(alpha,))
    d.ellipse((cx-rad,cy-rad,cx+rad,cy+rad),fill=shade(light,1.18)+(235,))
    # distant mountain ridge and broken silhouettes
    pts=[(0,151)]
    x=0; y=151
    while x<W:
        x+=rng.randint(28,82); y=rng.randint(104,160); pts.append((min(W,x),y))
    pts.extend([(W,207),(0,207)])
    d.polygon(pts,fill=pal['far']+(230,))
    # distant treeline / spires
    for x in range(-10,W+30,rng.randint(28,48)):
        base=rng.randint(172,208); h=rng.randint(18,55)
        if pal['kind'] in ('ruins','sanctum'):
            col=shade(pal['far'],.8)+(235,)
            ww=rng.randint(8,18)
            d.rectangle((x,base-h,x+ww,base),fill=col)
            d.rectangle((x-4,base-h-4,x+ww+4,base-h+3),fill=shade(col[:3],1.08)+(235,))
        else:
            col=shade(pal['far'],.78)+(235,)
            d.polygon([(x,base),(x+rng.randint(5,14),base-h),(x+rng.randint(14,24),base)],fill=col)
    # subtle stars/fireflies in upper area
    for _ in range(110):
        x=rng.randrange(W); y=rng.randrange(15,165)
        if rng.random()<.55:
            d.rectangle((x,y,x+1,y+1),fill=light+(rng.randint(35,120),))
    # MID: separate transparent silhouette depth.
    mid=Image.new('RGBA',(W,H),(0,0,0,0)); m=ImageDraw.Draw(mid)
    kind=pal['kind']; midc=pal['mid']; accent=pal['accent']
    for x in range(-40,W+80,rng.randint(125,185)):
        base=rng.randint(194,216)
        if kind=='forest':
            tw=rng.randint(14,26); th=rng.randint(90,160)
            m.rectangle((x,base-th,x+tw,base+18),fill=shade(midc,.82)+(255,))
            for _ in range(5):
                bx=x+rng.randint(-42,tw+36); by=base-th+rng.randint(-14,55); rr=rng.randint(25,48)
                m.ellipse((bx-rr,by-rr,bx+rr,by+rr),fill=midc+(245,))
                m.arc((bx-rr,by-rr,bx+rr,by+rr),190,300,fill=accent+(170,),width=2)
            m.line((x+tw//2,base-th+30,x+tw//2+30,base-th-12),fill=shade(midc,1.25)+(255,),width=5)
        elif kind=='ruins':
            ww=rng.randint(20,42); hh=rng.randint(62,145)
            m.rectangle((x,base-hh,x+ww,base),fill=midc+(245,))
            m.rectangle((x-5,base-hh-7,x+ww+5,base-hh+3),fill=accent+(245,))
            m.rectangle((x+5,base-hh+12,x+ww-5,base-hh+18),fill=shade(midc,1.25)+(200,))
            if rng.random()<.55:
                m.arc((x+ww,base-hh+12,x+ww+58,base-hh+95),180,360,fill=midc+(235,),width=10)
        elif kind=='marsh':
            tw=rng.randint(7,15); hh=rng.randint(70,142)
            m.line((x+tw//2,base-hh,x+tw//2,base+6),fill=midc+(245,),width=tw)
            for j in range(5):
                yy=base-hh+rng.randint(4,65); side=rng.choice([-1,1]); ln=rng.randint(25,62)
                m.line((x+tw//2,yy,x+tw//2+side*ln,yy-rng.randint(6,28)),fill=accent+(230,),width=4)
                leaf_y=yy-rng.randint(6,28); m.ellipse((x+tw//2+side*ln-4,leaf_y-4,x+tw//2+side*ln+4,leaf_y+4),fill=shade(accent,1.15)+(210,))
        elif kind=='void':
            # branching twisted roots
            start=(x,base); p1=(x+rng.randint(-25,25),base-rng.randint(45,90)); p2=(x+rng.randint(-70,80),base-rng.randint(95,165)); end=(x+rng.randint(-110,110),base-rng.randint(130,185))
            m.line([start,p1,p2,end],fill=midc+(245,),width=rng.randint(10,20),joint='curve')
            m.line([p1,(p1[0]+rng.randint(-35,35),p1[1]-55)],fill=accent+(210,),width=6)
        elif kind=='ice':
            ww=rng.randint(18,38); hh=rng.randint(92,175)
            m.polygon([(x,base),(x+ww//2,base-hh),(x+ww,base)],fill=midc+(245,))
            m.line((x+ww//2,base-hh+12,x+ww//2,base-8),fill=(185,231,255,150),width=2)
            m.polygon([(x-16,base),(x-3,base-rng.randint(36,75)),(x+9,base)],fill=accent+(225,))
        elif kind=='fire':
            ww=rng.randint(28,58); hh=rng.randint(80,160)
            m.polygon([(x,base),(x+ww//2,base-hh),(x+ww,base)],fill=midc+(245,))
            m.polygon([(x+ww*.42,base-hh*.65),(x+ww*.54,base-hh*.9),(x+ww*.67,base-hh*.62)],fill=accent+(220,))
            m.line((x+ww//2,base-5,x+ww//2+rng.randint(-12,12),base-hh//2),fill=(255,137,54,190),width=3)
        elif kind=='astral':
            ww=rng.randint(18,34); hh=rng.randint(100,185)
            m.rectangle((x,base-hh,x+ww,base),fill=midc+(245,))
            m.polygon([(x-8,base-hh+12),(x+ww//2,base-hh-20),(x+ww+8,base-hh+12)],fill=accent+(235,))
            m.arc((x-35,base-hh-55,x+ww+45,base-hh+50),190,345,fill=(221,199,255,205),width=3)
        else:
            # sanctum's giant trunk and broken columns
            if rng.random()<.5:
                ww=rng.randint(24,45); hh=rng.randint(100,172)
                m.rectangle((x,base-hh,x+ww,base+12),fill=midc+(250,))
                m.line((x+ww//2,base-hh+12,x+ww//2+25,base-hh-28),fill=accent+(220,),width=8)
            else:
                ww=rng.randint(15,28); hh=rng.randint(65,126)
                m.rectangle((x,base-hh,x+ww,base),fill=midc+(240,))
                m.rectangle((x-5,base-hh-8,x+ww+5,base-hh+2),fill=accent+(245,))
    # distant mist bands
    for yy in (164,180,196):
        alpha=rng.randint(14,26)
        m.rectangle((0,yy,W,yy+5),fill=pal['light']+(alpha,))
    # FRONT: walkable floor dressing, roots, stones, grass/reeds.
    front=Image.new('RGBA',(W,H),(0,0,0,0)); f=ImageDraw.Draw(front)
    ground=shade(pal['front'],1.0); edge=pal['accent']
    f.polygon([(0,195)]+[(x,190+rng.randint(-3,6)) for x in range(0,W+1,32)]+[(W,H),(0,H)],fill=ground+(250,))
    f.line([(0,195)]+[(x,190+rng.randint(-3,6)) for x in range(0,W+1,32)],fill=edge+(235,),width=3)
    # strata and subtle texture
    for yy in range(205,H,14):
        f.line((0,yy,W,yy),fill=shade(ground,1.22)+(95,),width=1)
        for _ in range(28):
            xx=rng.randrange(W); f.rectangle((xx,yy+rng.randrange(8),xx+rng.randrange(2,7),yy+rng.randrange(9,12)),fill=shade(edge,rng.uniform(.68,1.18))+(rng.randint(35,95),))
    for x in range(0,W, rng.randint(28,45)):
        y=194+rng.randint(-3,7)
        if kind in ('forest','marsh'):
            for j in range(rng.randint(3,7)):
                xx=x+rng.randint(-9,9); hh=rng.randint(6,19)
                f.line((xx,y,xx+rng.randint(-5,5),y-hh),fill=edge+(230,),width=2)
        elif kind=='void':
            f.line((x,y+12,x+rng.randint(10,28),y-rng.randint(4,17)),fill=accent+(240,),width=3)
        elif kind=='ice':
            f.polygon([(x-5,y),(x,y-rng.randint(15,30)),(x+8,y)],fill=accent+(225,))
            f.line((x+12,y,x+20,y-rng.randint(7,18)),fill=(181,226,250,210),width=2)
        elif kind=='fire':
            f.line((x,y,x+rng.randint(8,24),y-rng.randint(3,10)),fill=(255,115,42,230),width=3)
            f.ellipse((x+5,y-8,x+10,y-3),fill=(255,179,70,190))
        elif kind=='astral':
            f.line((x,y,x+rng.randint(12,24),y-rng.randint(7,16)),fill=(167,139,232,225),width=2)
            if rng.random()<.4: f.rectangle((x+8,y-13,x+10,y-11),fill=(233,218,255,220))
        else:
            f.line((x,y,x+rng.randint(-8,8),y-rng.randint(8,18)),fill=edge+(220,),width=2)
        if rng.random()<.45:
            ww=rng.randint(8,22); hh=rng.randint(5,12)
            f.ellipse((x+8,y-hh,x+8+ww,y+3),fill=shade(ground,1.65)+(220,))
            f.line((x+10,y-hh+2,x+8+ww-3,y-hh+2),fill=shade(edge,1.1)+(220,),width=1)
    # small glowing spores/embers
    for _ in range(65):
        x=rng.randrange(W); y=rng.randrange(145,202)
        rr=rng.choice([1,1,2]); f.ellipse((x-rr,y-rr,x+rr,y+rr),fill=pal['light']+(rng.randint(55,150),))
    # upscale nearest-neighbour, preserving transparency and crisp pixel edges.
    def upscale(im): return im.resize((1920,540),Image.Resampling.NEAREST)
    out=ROOT/'assets'/'parallax'; out.mkdir(parents=True,exist_ok=True)
    upscale(far).save(out/f'{theme}_far.png', optimize=True)
    upscale(mid).save(out/f'{theme}_mid.png', optimize=True)
    upscale(front).save(out/f'{theme}_front.png', optimize=True)

for idx,(theme,pal) in enumerate(BG.items()): create_layers(theme,pal,410+idx*97)

# HUD meters and enemy projectile visual.
ui=ROOT/'assets'/'ui'; ui.mkdir(exist_ok=True)
def save_bar(path, base, highlight, border=(8,12,20,255)):
    im=Image.new('RGBA',(128,16),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.rounded_rectangle((0,0,127,15),radius=3,fill=border,outline=(198,177,126,255),width=1)
    d.rectangle((3,3,124,12),fill=base)
    d.line((4,4,123,4),fill=highlight,width=1)
    im.save(path,optimize=True)
save_bar(ui/'hud_bar_bg.png',(18,23,31,255),(56,65,72,255))
save_bar(ui/'hud_hp_fill.png',(152,48,57,255),(244,124,108,255), (0,0,0,0))
save_bar(ui/'hud_mp_fill.png',(45,104,163,255),(126,202,244,255), (0,0,0,0))
save_bar(ui/'hud_boss_fill.png',(133,57,142,255),(235,137,220,255), (0,0,0,0))
vfx=ROOT/'assets'/'vfx'; vfx.mkdir(exist_ok=True)
orb=Image.new('RGBA',(24,24),(0,0,0,0)); od=ImageDraw.Draw(orb)
od.ellipse((1,1,22,22),fill=(80,176,230,65))
od.ellipse((4,4,19,19),fill=(65,145,226,210),outline=(177,229,255,255),width=2)
od.ellipse((8,7,13,12),fill=(240,255,255,245))
orb.save(vfx/'enemy_bolt.png',optimize=True)

