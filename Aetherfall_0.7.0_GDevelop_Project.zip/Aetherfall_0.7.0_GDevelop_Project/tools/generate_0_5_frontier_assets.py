#!/usr/bin/env python3
"""Generate missing 0.5 frontier pixel backgrounds and unique enemy sprite frames."""
from pathlib import Path
from PIL import Image, ImageDraw
import math, random
ROOT = Path(__file__).resolve().parents[1]

# The parallax generator creates transparent layers at 1920x540. Composite matching
# 960x540 backplates for menus/areas where the camera is not scrolling.
for theme in ['frozen_wastes', 'ashen_caldera', 'fallen_astral_spire']:
    layers = [Image.open(ROOT/'assets'/'parallax'/f'{theme}_{layer}.png').convert('RGBA').resize((960,540), Image.Resampling.NEAREST)
              for layer in ['far','mid','front']]
    base = Image.new('RGBA',(960,540),(7,11,20,255))
    for layer in layers:
        base.alpha_composite(layer)
    base.convert('RGB').save(ROOT/'assets'/'backgrounds'/f'{theme}.png', optimize=True)

# New archetypes require distinct silhouettes and complete 4x6 frame animations.
ENEMIES = {
 'frost_howler':      {'size':48,'kind':'wolf','body':(74,126,166),'light':(180,235,255),'dark':(30,57,91),'accent':(97,209,245)},
 'crystal_guardian':  {'size':48,'kind':'golem','body':(51,109,132),'light':(156,238,235),'dark':(23,48,69),'accent':(75,217,219)},
 'ember_hound':       {'size':48,'kind':'wolf','body':(174,70,39),'light':(255,187,83),'dark':(67,29,28),'accent':(255,94,35)},
 'cinder_mage':       {'size':48,'kind':'mage','body':(105,46,39),'light':(239,154,78),'dark':(43,22,31),'accent':(255,91,36)},
 'ash_golem':         {'size':48,'kind':'golem','body':(86,62,57),'light':(190,105,64),'dark':(37,28,30),'accent':(255,103,38)},
 'star_reaver':       {'size':48,'kind':'wraith','body':(74,60,126),'light':(197,178,255),'dark':(22,18,51),'accent':(130,99,231)},
 'astral_seraph':     {'size':48,'kind':'seraph','body':(127,113,174),'light':(244,229,255),'dark':(43,37,85),'accent':(181,155,255)},
 'glacier_colossus':  {'size':64,'kind':'ice_boss','body':(71,128,174),'light':(210,248,255),'dark':(24,51,86),'accent':(104,218,255)},
 'ember_drake':       {'size':64,'kind':'drake','body':(146,50,34),'light':(255,190,86),'dark':(49,20,24),'accent':(255,79,28)},
 'astral_archon':     {'size':64,'kind':'archon','body':(92,67,157),'light':(236,219,255),'dark':(25,18,59),'accent':(180,123,255)},
}

def shade(c, k):
    return tuple(max(0,min(255,int(v*k))) for v in c)

def draw_enemy(name, spec, anim, frame):
    n=spec['size']; c=spec['body']; hi=spec['light']; dark=spec['dark']; ac=spec['accent']
    im=Image.new('RGBA',(n,n),(0,0,0,0)); d=ImageDraw.Draw(im)
    _rectangle=d.rectangle
    def safe_rectangle(xy, *args, **kwargs):
        x1,y1,x2,y2=xy
        return _rectangle((min(x1,x2),min(y1,y2),max(x1,x2),max(y1,y2)), *args, **kwargs)
    d.rectangle=safe_rectangle
    phase=(frame-1)/5*math.tau
    bob=round(math.sin(phase)*1.4) if anim=='idle' else (round(math.sin(phase*2)*2) if anim=='move' else 0)
    lean=2 if anim=='attack' else (1 if anim=='telegraph' else 0)
    # A small ellipse shadow gives each sprite a grounded silhouette.
    d.ellipse((n*.18,n*.82,n*.82,n*.93),fill=(5,8,14,105))
    k=spec['kind']
    if k=='wolf':
        # Four-legged hunter with unmistakable muzzle, ears, tail and back spines.
        y=round(n*.54+bob)
        d.polygon([(n*.22,y-8),(n*.34,y-14),(n*.67,y-13),(n*.78,y-4),(n*.7,y+5),(n*.28,y+5)],fill=dark)
        d.polygon([(n*.24,y-9),(n*.38,y-16),(n*.67,y-14),(n*.77,y-5),(n*.69,y+2),(n*.3,y+2)],fill=c)
        d.polygon([(n*.63,y-11),(n*.69,y-22),(n*.77,y-13),(n*.82,y-9),(n*.78,y)],fill=shade(c,.78))
        d.polygon([(n*.69,y-17),(n*.72,y-25),(n*.78,y-16)],fill=hi)
        d.polygon([(n*.23,y-8),(n*.16,y-19),(n*.34,y-13)],fill=shade(c,.72))
        d.polygon([(n*.15,y-16),(n*.18,y-23),(n*.22,y-15)],fill=hi)
        d.polygon([(n*.75,y-9),(n*.9,y-13),(n*.86,y-5),(n*.75,y-3)],fill=ac)
        d.polygon([(n*.77,y-7),(n*.9,y-7),(n*.83,y-2)],fill=hi)
        d.rectangle((n*.32,y+1,n*.4,n*.83),fill=dark); d.rectangle((n*.58,y+1,n*.66,n*.83),fill=dark)
        d.rectangle((n*.3,y+1,n*.37,n*.78),fill=c); d.rectangle((n*.56,y+1,n*.63,n*.78),fill=c)
        d.rectangle((n*.7,y-10,n*.73,y-7),fill=(255,239,156,255))
        if name=='frost_howler':
            for x in [n*.39,n*.49,n*.59]: d.polygon([(x,y-13),(x+3,y-22),(x+7,y-12)],fill=ac)
            d.line((n*.35,y-2,n*.61,y-2),fill=hi,width=2)
        else:
            d.polygon([(n*.42,y-14),(n*.46,y-23),(n*.5,y-13)],fill=(255,213,111,255))
            d.polygon([(n*.55,y-14),(n*.61,y-25),(n*.64,y-11)],fill=ac)
    elif k=='golem':
        y=round(n*.2+bob)
        # Broad stone shoulders, angular torso, block legs and crystal plate seams.
        d.rectangle((n*.28,y+14,n*.72,n*.7),fill=dark)
        d.polygon([(n*.28,y+12),(n*.2,y+17),(n*.16,y+34),(n*.28,y+42),(n*.38,y+36)],fill=shade(c,.78))
        d.polygon([(n*.72,y+12),(n*.8,y+17),(n*.84,y+34),(n*.72,y+42),(n*.62,y+36)],fill=shade(c,.78))
        d.polygon([(n*.33,y+12),(n*.67,y+12),(n*.74,y+44),(n*.63,y+58),(n*.37,y+58),(n*.26,y+44)],fill=c)
        d.rectangle((n*.37,y+2,n*.63,y+23),fill=shade(c,1.12),outline=dark,width=2)
        d.polygon([(n*.4,y+5),(n*.5,y-1),(n*.6,y+5),(n*.57,y+20),(n*.43,y+20)],fill=shade(c,1.23))
        d.rectangle((n*.42,y+12,n*.46,y+15),fill=(255,245,174,255)); d.rectangle((n*.55,y+12,n*.59,y+15),fill=(255,245,174,255))
        d.polygon([(n*.5,y+24),(n*.58,y+36),(n*.5,y+48),(n*.42,y+36)],fill=ac)
        d.rectangle((n*.34,y+53,n*.46,y+0.88*n),fill=dark); d.rectangle((n*.55,y+53,n*.67,y+0.88*n),fill=dark)
        if name=='crystal_guardian':
            for x in [n*.18,n*.75,n*.5]: d.polygon([(x,y+17),(x+4,y+1),(x+10,y+17)],fill=ac)
            d.line((n*.3,y+32,n*.44,y+43,n*.38,y+54),fill=hi,width=2)
        else:
            d.line((n*.3,y+30,n*.43,y+35,n*.38,y+48),fill=ac,width=3)
            d.line((n*.57,y+37,n*.69,y+30,n*.65,y+48),fill=(255,141,51,255),width=3)
    elif k=='mage':
        y=round(n*.17+bob)
        d.polygon([(n*.5,y),(n*.21,y+15),(n*.31,y+24),(n*.2,n*.86),(n*.8,n*.86),(n*.69,y+24),(n*.79,y+15)],fill=dark)
        d.polygon([(n*.5,y+5),(n*.28,y+22),(n*.35,y+31),(n*.26,n*.82),(n*.74,n*.82),(n*.65,y+31),(n*.72,y+22)],fill=c)
        d.polygon([(n*.5,y-2),(n*.27,y+18),(n*.5,y+15),(n*.73,y+18)],fill=shade(c,1.24))
        d.ellipse((n*.39,y+17,n*.61,y+37),fill=dark)
        d.rectangle((n*.43,y+24,n*.47,y+27),fill=hi); d.rectangle((n*.54,y+24,n*.58,y+27),fill=hi)
        sx=n*.83; d.line((sx,y+5,sx,n*.81),fill=shade(dark,1.4),width=3)
        d.ellipse((sx-5,y-1,sx+5,y+9),fill=ac,outline=hi,width=1)
        d.polygon([(n*.28,n*.83),(n*.72,n*.83),(n*.78,n*.9),(n*.22,n*.9)],fill=dark)
        d.rectangle((n*.47,n*.47,n*.54,n*.56),fill=ac)
    elif k=='wraith':
        y=round(n*.13+bob)
        d.polygon([(n*.25,y+20),(n*.5,y-2),(n*.75,y+20),(n*.69,y+52),(n*.84,n*.87),(n*.5,n*.76),(n*.16,n*.87),(n*.31,y+52)],fill=dark)
        d.polygon([(n*.31,y+21),(n*.5,y+3),(n*.69,y+21),(n*.64,y+52),(n*.76,n*.8),(n*.5,n*.72),(n*.24,n*.8),(n*.36,y+52)],fill=c)
        d.polygon([(n*.35,y+10),(n*.5,y-2),(n*.65,y+10),(n*.61,y+26),(n*.39,y+26)],fill=dark)
        d.rectangle((n*.39,y+14,n*.46,y+17),fill=hi); d.rectangle((n*.54,y+14,n*.61,y+17),fill=hi)
        d.line((n*.75,y+25,n*.92,y+5,n*.89,y+42),fill=hi,width=2)
        d.polygon([(n*.88,y+4),(n*.97,y-2),(n*.93,y+12)],fill=ac)
        for x in [n*.27,n*.67]: d.polygon([(x,y+37),(x-4,y+48),(x+5,y+44)],fill=ac)
    elif k=='seraph':
        y=round(n*.16+bob)
        # Symmetric segmented wings, halo, robe and light spear.
        d.ellipse((n*.37,y-7,n*.63,y+4),outline=hi,width=2)
        for side in [-1,1]:
            x=n*.5+side*n*.12
            d.polygon([(x,y+18),(x+side*n*.28,y-1),(x+side*n*.34,y+18),(x+side*n*.23,y+37),(x,y+31)],fill=dark)
            for j in range(3):
                d.line((x+side*2,y+8+j*8,x+side*(n*.2+j*3),y+4+j*11),fill=hi,width=2)
        d.polygon([(n*.5,y+5),(n*.32,y+21),(n*.39,n*.83),(n*.61,n*.83),(n*.68,y+21)],fill=c)
        d.ellipse((n*.4,y+8,n*.6,y+30),fill=shade(c,1.32))
        d.rectangle((n*.44,y+18,n*.48,y+21),fill=(255,244,180,255));d.rectangle((n*.53,y+18,n*.57,y+21),fill=(255,244,180,255))
        d.line((n*.77,y+7,n*.77,n*.85),fill=hi,width=2);d.polygon([(n*.77,y+2),(n*.72,y+13),(n*.82,y+13)],fill=ac)
    elif k=='ice_boss':
        y=round(n*.13+bob)
        # Towering ice titan with horn crown and heavy crystalline fists.
        d.polygon([(n*.25,y+23),(n*.18,y+9),(n*.31,y+14),(n*.39,y-1),(n*.5,y+14),(n*.61,y-1),(n*.69,y+14),(n*.82,y+8),(n*.75,y+28)],fill=ac)
        d.polygon([(n*.29,y+18),(n*.71,y+18),(n*.82,y+44),(n*.74,y+62),(n*.26,y+62),(n*.18,y+44)],fill=dark)
        d.polygon([(n*.32,y+19),(n*.68,y+19),(n*.76,y+43),(n*.68,y+56),(n*.32,y+56),(n*.24,y+43)],fill=c)
        d.polygon([(n*.25,y+24),(n*.1,y+29),(n*.06,y+48),(n*.23,y+56),(n*.36,y+43)],fill=shade(c,.76))
        d.polygon([(n*.75,y+24),(n*.9,y+29),(n*.94,y+48),(n*.77,y+56),(n*.64,y+43)],fill=shade(c,.76))
        d.rectangle((n*.32,y+5,n*.68,y+29),fill=shade(c,1.28),outline=dark,width=2)
        d.rectangle((n*.39,y+16,n*.45,y+19),fill=hi);d.rectangle((n*.55,y+16,n*.61,y+19),fill=hi)
        d.polygon([(n*.5,y+25),(n*.64,y+43),(n*.5,y+54),(n*.36,y+43)],fill=ac)
        d.polygon([(n*.32,y+56),(n*.46,y+56),(n*.43,n*.93),(n*.26,n*.93)],fill=dark)
        d.polygon([(n*.54,y+56),(n*.68,y+56),(n*.74,n*.93),(n*.57,n*.93)],fill=dark)
        for x in [n*.26,n*.73]:d.polygon([(x,y+34),(x+4,y+17),(x+9,y+36)],fill=hi)
    elif k=='drake':
        y=round(n*.22+bob)
        # Four-limbed dragon with broad wings, horned head and long flaming tail.
        d.polygon([(n*.5,y+21),(n*.13,y-3),(n*.24,y+28),(n*.39,y+34)],fill=dark)
        d.polygon([(n*.5,y+21),(n*.87,y-3),(n*.76,y+28),(n*.61,y+34)],fill=shade(c,.76))
        d.polygon([(n*.5,y+16),(n*.31,y+27),(n*.28,y+50),(n*.48,y+59),(n*.7,y+48),(n*.68,y+27)],fill=c,outline=dark)
        d.polygon([(n*.63,y+25),(n*.78,y+8),(n*.94,y+12),(n*.86,y+28),(n*.72,y+35)],fill=shade(c,1.17))
        d.polygon([(n*.77,y+11),(n*.8,y-2),(n*.85,y+12)],fill=hi)
        d.rectangle((n*.82,y+15,n*.86,y+18),fill=(255,246,169,255))
        d.polygon([(n*.33,y+46),(n*.42,y+51),(n*.38,n*.9),(n*.29,n*.9)],fill=dark)
        d.polygon([(n*.57,y+46),(n*.67,y+48),(n*.72,n*.9),(n*.62,n*.9)],fill=dark)
        d.line((n*.3,y+36,n*.1,y+47,n*.03,y+36),fill=ac,width=4)
        d.polygon([(n*.03,y+36),(n*.0,y+25),(n*.13,y+40)],fill=hi)
        d.line((n*.4,y+36,n*.5,y+46,n*.6,y+34),fill=hi,width=2)
    elif k=='archon':
        y=round(n*.12+bob)
        # Final astral sovereign: crowned mask, floating mantle and orbiting halo.
        d.ellipse((n*.2,y-2,n*.8,y+18),outline=ac,width=2)
        d.polygon([(n*.5,y-5),(n*.36,y+12),(n*.27,y+28),(n*.34,y+55),(n*.5,n*.92),(n*.66,y+55),(n*.73,y+28),(n*.64,y+12)],fill=dark)
        d.polygon([(n*.5,y+1),(n*.38,y+18),(n*.35,y+52),(n*.5,n*.84),(n*.65,y+52),(n*.62,y+18)],fill=c)
        d.polygon([(n*.32,y+10),(n*.5,y-9),(n*.68,y+10),(n*.62,y+33),(n*.38,y+33)],fill=shade(c,1.25))
        d.polygon([(n*.38,y+2),(n*.5,y-13),(n*.62,y+2)],fill=ac)
        d.rectangle((n*.42,y+16,n*.47,y+19),fill=hi);d.rectangle((n*.53,y+16,n*.58,y+19),fill=hi)
        d.line((n*.75,y+12,n*.92,y+55),fill=hi,width=3)
        d.ellipse((n*.86,y+3,n*.98,y+15),fill=ac,outline=hi,width=2)
        for i in range(3):
            xx=n*(.24+i*.26);d.rectangle((xx,y+42,xx+3,y+48),fill=hi)
    # Telegraph/attack cues: keep silhouette readable and communicate danger.
    if anim=='telegraph':
        d.line((n*.12,n*.91,n*.88,n*.91),fill=(255,90,68,200),width=2)
        d.rectangle((n*.08,n*.07,n*.12,n*.12),fill=(255,213,137,255))
    elif anim=='attack':
        d.polygon([(n*.82,n*.32),(n*.98,n*.22),(n*.92,n*.43)],fill=hi)
        if frame%2==0:d.line((n*.65,n*.45,n*.96,n*.48),fill=ac,width=2)
    # Fine pixel highlights vary by animation frame to avoid a static cutout look.
    if frame in (2,5): d.rectangle((n*.14,n*.64,n*.18,n*.68),fill=hi)
    if frame in (3,6): d.rectangle((n*.79,n*.59,n*.84,n*.63),fill=ac)
    return im

for name,spec in ENEMIES.items():
    size=spec['size']
    # Base key is used by tools/inspectors and remains a separate static resource.
    draw_enemy(name,spec,'idle',1).save(ROOT/'assets'/'sprites'/f'{name}.png', optimize=True)
    for anim in ['idle','move','telegraph','attack']:
        for frame in range(1,7):
            draw_enemy(name,spec,anim,frame).save(ROOT/'assets'/'sprites'/f'{name}_{anim}_{frame}.png', optimize=True)

print('Generated 3 frontier backgrounds, 9 parallax layers (via base generator), and 10 unique enemy sprites with 4x6 animation frames.')
