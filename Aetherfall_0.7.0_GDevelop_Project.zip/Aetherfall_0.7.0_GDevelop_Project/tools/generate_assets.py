from PIL import Image, ImageDraw
from pathlib import Path
import random, math, shutil
ROOT=Path(__file__).resolve().parents[1]/'assets'
SPR=ROOT/'sprites'; BG=ROOT/'backgrounds'; TS=ROOT/'tilesets'; IC=ROOT/'icons'; UI=ROOT/'ui'
for p in (SPR,BG,TS,IC,UI): p.mkdir(parents=True,exist_ok=True)
# Crop the existing 6x4 sprite sheets into individual animation frames.
for src,name,cell in [(SPR/'hero.png','hero',48),(SPR/'moss_goblin.png','moss_goblin',48),(SPR/'forest_brute.png','forest_brute',48),(SPR/'ancient_grove_warden.png','warden',64)]:
    if not src.exists(): continue
    sheet=Image.open(src).convert('RGBA')
    for r,anim in enumerate(['idle','move','telegraph','attack']):
        for c in range(6):
            frame=sheet.crop((c*cell,r*cell,(c+1)*cell,(r+1)*cell))
            frame.save(SPR/f'{name}_{anim}_{c+1}.png')
# New silhouette enemy sheets.
styles={
 'moss_shaman':((106,154,111),(37,65,55),'shaman'),
 'thorn_stalker':((168,103,73),(63,39,39),'stalker'),
 'moon_wisp':((106,180,211),(33,61,91),'wisp'),
 'bog_lurker':((113,132,67),(42,54,35),'lurker'),
 'void_crawler':((153,101,186),(54,35,85),'crawler'),
 'drowned_sentinel':((70,144,166),(27,56,77),'sentinel'),
 'frost_howler':((164,216,238),(43,91,126),'wolf'),
 'crystal_guardian':((117,203,225),(39,73,112),'crystal'),
 'ember_hound':((230,112,48),(91,38,27),'hound'),
 'cinder_mage':((232,130,57),(85,40,34),'cinder'),
 'ash_golem':((151,104,77),(58,47,45),'golem'),
 'star_reaver':((193,155,235),(54,39,91),'reaver'),
 'astral_seraph':((207,219,247),(63,75,139),'seraph'),
 'glacier_colossus':((140,209,244),(33,78,123),'ice_boss'),
 'ember_drake':((234,91,45),(83,28,25),'drake_boss'),
 'astral_archon':((203,157,248),(55,33,96),'archon_boss'),
}
for name,(main,dark,kind) in styles.items():
    sheet=Image.new('RGBA',(288,192),(0,0,0,0))
    for r in range(4):
      for c in range(6):
        im=Image.new('RGBA',(48,48),(0,0,0,0)); d=ImageDraw.Draw(im)
        bob=(c%3)-1 if r in (0,1) else 0
        # base silhouette differs by archetype
        if kind=='wisp':
          d.ellipse((13,12+bob,35,35+bob),fill=dark,outline=(198,231,255),width=1)
          d.ellipse((17,16+bob,31,30+bob),fill=main)
          d.polygon([(14,27+bob),(5,34+bob),(14,32+bob),(8,41),(21,34+bob)],fill=main)
          d.polygon([(34,26+bob),(43,34+bob),(34,32+bob),(40,41),(27,34+bob)],fill=main)
        elif kind=='crawler':
          d.ellipse((12,15+bob,36,34+bob),fill=main,outline=dark,width=2)
          for k in range(4):
            x=13+k*7
            d.line((x,26+bob,x-8,34+bob+(k%2)*4),fill=dark,width=3)
            d.line((x+3,26+bob,x+10,34+bob+(k%2)*4),fill=dark,width=3)
          d.ellipse((20,19+bob,24,23+bob),fill=(255,220,160)); d.ellipse((28,19+bob,32,23+bob),fill=(255,220,160))
        elif kind=='sentinel':
          d.rectangle((13,11+bob,35,38+bob),fill=dark,outline=(132,207,218))
          d.rectangle((16,14+bob,32,34+bob),fill=main)
          d.polygon([(14,14+bob),(8,4+bob),(19,11+bob)],fill=dark)
          d.polygon([(34,14+bob),(40,4+bob),(29,11+bob)],fill=dark)
          d.rectangle((20,18+bob,23,22+bob),fill=(225,246,255)); d.rectangle((27,18+bob,30,22+bob),fill=(225,246,255))
          d.rectangle((9,26+bob,14,36+bob),fill=dark); d.rectangle((34,26+bob,39,36+bob),fill=dark)
        elif kind=='shaman':
          d.polygon([(24,2+bob),(9,17+bob),(14,39+bob),(34,39+bob),(39,17+bob)],fill=dark)
          d.ellipse((15,11+bob,33,30+bob),fill=main,outline=dark)
          d.polygon([(12,14+bob),(24,0+bob),(36,14+bob)],fill=(86,104,71))
          d.ellipse((19,19+bob,22,22+bob),fill=(250,219,133)); d.ellipse((27,19+bob,30,22+bob),fill=(250,219,133))
          d.line((37,17+bob,42,40),fill=(130,91,57),width=3); d.ellipse((35,7+bob,44,16+bob),fill=(190,220,158))
        elif kind=='stalker':
          d.polygon([(24,3+bob),(15,14+bob),(11,36+bob),(37,36+bob),(33,14+bob)],fill=dark)
          d.polygon([(16,17+bob),(24,7+bob),(32,17+bob),(29,32+bob),(19,32+bob)],fill=main)
          d.polygon([(15,13+bob),(4,3+bob),(14,8+bob)],fill=dark); d.polygon([(33,13+bob),(44,3+bob),(34,8+bob)],fill=dark)
          d.line((18,22+bob,22,22+bob),fill=(255,231,170),width=2); d.line((27,22+bob,31,22+bob),fill=(255,231,170),width=2)
          d.line((17,34+bob,9,44),fill=dark,width=4); d.line((31,34+bob,40,44),fill=dark,width=4)
        elif kind in ('wolf','hound','reaver'):
          # Low, predatory silhouette with distinct ears, muzzle and articulated legs.
          d.ellipse((9,14+bob,39,34+bob),fill=dark,outline=main,width=2)
          d.polygon([(13,18+bob),(8,4+bob),(20,13+bob)],fill=main)
          d.polygon([(28,13+bob),(40,4+bob),(36,20+bob)],fill=main)
          d.polygon([(31,22+bob),(45,25+bob),(34,30+bob)],fill=main)
          eye=(255,237,179) if kind!='reaver' else (210,187,255)
          d.rectangle((27,20+bob,30,22+bob),fill=eye)
          d.line((15,31+bob,10,43),fill=dark,width=4); d.line((32,31+bob,39,43),fill=dark,width=4)
          d.line((12,23+bob,4,17+bob),fill=main,width=3)
          if kind=='reaver':
            d.line((23,13+bob,24,3+bob),fill=(236,218,255),width=2)
            d.line((33,17+bob,44,13+bob),fill=(236,218,255),width=2)
        elif kind=='crystal':
          d.polygon([(24,3+bob),(34,14+bob),(39,31+bob),(28,43+bob),(14,38+bob),(9,19+bob)],fill=dark,outline=main)
          d.polygon([(24,7+bob),(31,18+bob),(26,35+bob),(16,30+bob)],fill=main)
          d.polygon([(10,18+bob),(3,7+bob),(16,14+bob)],fill=main)
          d.polygon([(37,18+bob),(45,6+bob),(33,15+bob)],fill=main)
          d.rectangle((18,21+bob,21,24+bob),fill=(246,255,255)); d.rectangle((28,21+bob,31,24+bob),fill=(246,255,255))
        elif kind=='cinder':
          d.polygon([(24,2+bob),(10,15+bob),(13,40+bob),(35,40+bob),(38,15+bob)],fill=dark)
          d.ellipse((15,12+bob,33,31+bob),fill=main,outline=dark)
          d.polygon([(14,14+bob),(24,0+bob),(34,14+bob),(27,11+bob)],fill=(91,35,27))
          d.rectangle((19,21+bob,22,24+bob),fill=(255,240,153)); d.rectangle((27,21+bob,30,24+bob),fill=(255,240,153))
          d.line((38,17+bob,43,42),fill=(127,78,48),width=3)
          d.ellipse((37,6+bob,46,15+bob),fill=(255,132,45),outline=(255,210,120))
        elif kind=='golem':
          d.rounded_rectangle((6,13+bob,42,41+bob),radius=7,fill=dark,outline=main,width=2)
          d.polygon([(9,17+bob),(14,5+bob),(23,14+bob),(33,4+bob),(40,18+bob)],fill=main)
          d.rectangle((15,23+bob,20,27+bob),fill=(255,183,94)); d.rectangle((28,23+bob,33,27+bob),fill=(255,183,94))
          d.line((12,35+bob,7,45),fill=dark,width=6); d.line((36,35+bob,42,45),fill=dark,width=6)
        elif kind=='seraph':
          d.polygon([(20,17+bob),(5,7+bob),(2,18+bob),(15,28+bob)],fill=dark,outline=main)
          d.polygon([(28,17+bob),(43,7+bob),(46,18+bob),(33,28+bob)],fill=dark,outline=main)
          d.ellipse((17,10+bob,31,25+bob),fill=main,outline=dark,width=2)
          d.polygon([(17,24+bob),(31,24+bob),(35,40+bob),(14,40+bob)],fill=dark)
          d.arc((12,0+bob,36,18+bob),180,360,fill=(255,244,199),width=2)
          d.rectangle((20,16+bob,22,19+bob),fill=(255,255,255)); d.rectangle((27,16+bob,29,19+bob),fill=(255,255,255))
        elif kind=='ice_boss':
          d.polygon([(24,1+bob),(32,12+bob),(43,18+bob),(39,41+bob),(9,41+bob),(5,18+bob),(16,12+bob)],fill=dark,outline=main)
          d.polygon([(24,5+bob),(30,19+bob),(25,35+bob),(15,30+bob)],fill=main)
          d.polygon([(14,14+bob),(3,2+bob),(18,9+bob)],fill=main); d.polygon([(34,10+bob),(45,1+bob),(37,17+bob)],fill=main)
          d.rectangle((17,21+bob,21,25+bob),fill=(240,255,255)); d.rectangle((28,21+bob,32,25+bob),fill=(240,255,255))
        elif kind=='drake_boss':
          d.ellipse((8,13+bob,39,37+bob),fill=dark,outline=main,width=2)
          d.polygon([(12,19+bob),(7,3+bob),(20,15+bob)],fill=main); d.polygon([(30,15+bob),(44,2+bob),(38,23+bob)],fill=main)
          d.polygon([(17,18+bob),(4,11+bob),(10,29+bob),(20,25+bob)],fill=main)
          d.polygon([(32,18+bob),(45,11+bob),(39,29+bob),(29,25+bob)],fill=main)
          d.polygon([(34,29+bob),(46,34+bob),(35,36+bob)],fill=main)
          d.rectangle((25,21+bob,29,24+bob),fill=(255,240,164))
        elif kind=='archon_boss':
          d.polygon([(24,2+bob),(39,15+bob),(35,40+bob),(13,40+bob),(9,15+bob)],fill=dark,outline=main,width=2)
          d.ellipse((14,7+bob,34,28+bob),fill=main,outline=dark,width=2)
          d.polygon([(24,0+bob),(18,12+bob),(24,8+bob),(30,12+bob)],fill=(245,229,255))
          d.line((7,17+bob,16,27+bob),fill=(226,194,255),width=4); d.line((41,17+bob,32,27+bob),fill=(226,194,255),width=4)
          d.rectangle((19,17+bob,22,21+bob),fill=(255,255,255)); d.rectangle((27,17+bob,30,21+bob),fill=(255,255,255))
        else: # bog lurker
          d.ellipse((11,13+bob,37,38+bob),fill=dark)
          d.ellipse((15,16+bob,33,34+bob),fill=main)
          d.polygon([(12,21+bob),(3,10+bob),(16,17+bob)],fill=dark); d.polygon([(36,21+bob),(45,10+bob),(32,17+bob)],fill=dark)
          d.ellipse((18,22+bob,22,26+bob),fill=(238,235,132)); d.ellipse((27,22+bob,31,26+bob),fill=(238,235,132))
          d.line((14,34+bob,5,44),fill=dark,width=4); d.line((34,34+bob,43,44),fill=dark,width=4)
        # hit/attack frames show a brighter accent / spread limbs
        if r==2:
          d.line((8,24,40,24),fill=(246,202,120),width=2)
        if r==3:
          d.line((7,21,1,12),fill=main,width=4); d.line((41,21,47,12),fill=main,width=4)
        sheet.paste(im,(c*48,r*48),im)
    sheet.save(SPR/f'{name}.png')
    for r,anim in enumerate(['idle','move','telegraph','attack']):
      for c in range(6): sheet.crop((c*48,r*48,(c+1)*48,(r+1)*48)).save(SPR/f'{name}_{anim}_{c+1}.png')
# Region backgrounds: stylized low-resolution parallax plates.
region_palette=[('whisper_forest',(18,37,37),(42,78,62),(96,128,84)),('moss_ruins',(31,36,42),(69,78,76),(128,125,95)),('moon_marsh',(14,34,47),(37,77,80),(91,142,132)),('void_roots',(26,19,42),(67,40,78),(128,72,128)),('ancient_sanctum',(37,28,35),(91,69,58),(189,142,80)),('frozen_wastes',(12,28,48),(51,91,128),(139,192,220)),('ashen_caldera',(39,19,17),(112,48,30),(205,87,40)),('fallen_astral_spire',(17,13,43),(62,48,113),(155,119,214))]
for name,sky,mid,front in region_palette:
    random.seed(name)
    w,h=480,270
    im=Image.new('RGB',(w,h),sky); d=ImageDraw.Draw(im)
    # distant hills / skyline
    for x in range(-20,w+20,25):
      y=random.randint(75,140)
      d.ellipse((x-30,y-18,x+40,y+42),fill=mid)
    # pillars / trees / roots / ruins silhouettes
    for i in range(18):
      x=random.randint(0,w); base=random.randint(170,225)
      if 'forest' in name or 'roots' in name:
        d.rectangle((x,base-90,x+random.randint(5,13),h),fill=front)
        for q in range(3):
          yy=base-80+q*25; d.polygon([(x-25,yy+22),(x+6,yy-12),(x+35,yy+20)],fill=mid)
      elif 'ruins' in name or 'sanctum' in name:
        d.rectangle((x,base-55,x+random.randint(10,22),h),fill=front)
        d.rectangle((x-4,base-60,x+26,base-53),fill=mid)
      else:
        d.ellipse((x-12,base-25,x+24,base+2),fill=front)
        d.line((x+3,base,x+3,h),fill=mid,width=4)
    # ground
    d.rectangle((0,225,w,h),fill=(25,30,31))
    for _ in range(280):
      x=random.randrange(w); y=random.randrange(226,h); col=random.choice([front,mid,(38,46,42)])
      d.rectangle((x,y,x+random.randrange(1,4),y+random.randrange(1,3)),fill=col)
    im.resize((960,540),Image.Resampling.NEAREST).save(BG/f'{name}.png')
# Region tilesets: 8-column tile atlases (16x16 tiles).
for name,_,mid,front in region_palette:
    im=Image.new('RGBA',(16*8,16*4),(0,0,0,0)); d=ImageDraw.Draw(im)
    random.seed(name+'tiles')
    base=front
    for y in range(4):
      for x in range(8):
        xx,yy=x*16,y*16
        col=tuple(max(0,min(255,int(c*random.uniform(.75,1.18)))) for c in base)
        d.rectangle((xx,yy,xx+15,yy+15),fill=col)
        for _ in range(8):
          px=xx+random.randrange(16); py=yy+random.randrange(16)
          d.point((px,py),fill=mid)
        if y==0: d.line((xx,yy,xx+15,yy),fill=(190,170,120,255),width=1)
    im.save(TS/f'{name}_tiles.png')
# Simple item icons.
items=[('sword',(190,204,219),'weapon'),('armor',(120,144,155),'armor'),('ring',(222,190,96),'ring'),('hp_potion',(202,65,76),'potion'),('mp_potion',(70,130,220),'potion'),('antidote',(105,184,98),'herb'),('roast_meat',(184,105,63),'food'),('grilled_fish',(90,151,176),'food'),('mushroom_soup',(185,128,202),'food'),('moon_fruit',(164,198,100),'food'),('ore',(130,140,154),'material'),('root',(154,116,82),'material')]
for name,col,kind in items:
 im=Image.new('RGBA',(32,32),(0,0,0,0)); d=ImageDraw.Draw(im)
 if kind in ('weapon','armor','ring'):
  if kind=='weapon': d.polygon([(7,26),(11,22),(23,5),(27,8),(14,25),(9,29)],fill=col,outline=(245,235,207)); d.rectangle((5,22,16,25),fill=(124,83,53))
  elif kind=='armor': d.polygon([(7,7),(13,4),(19,4),(25,7),(23,26),(16,30),(9,26)],fill=col,outline=(226,223,196)); d.line((16,6,16,26),fill=(39,48,59),width=2)
  else: d.ellipse((5,6,27,28),outline=col,width=5); d.ellipse((11,12,21,22),fill=(27,29,36))
 elif kind=='potion':
  d.rectangle((12,3,20,9),fill=(207,190,143)); d.polygon([(10,8),(22,8),(25,14),(23,28),(9,28),(7,14)],fill=col,outline=(235,226,197)); d.rectangle((10,18,22,24),fill=tuple(min(255,c+45) for c in col))
 elif kind=='food':
  d.ellipse((5,9,27,26),fill=col,outline=(230,218,182)); d.arc((6,8,26,28),180,360,fill=(245,232,192),width=2)
 elif kind=='herb':
  d.line((16,28,16,9),fill=(94,133,67),width=3); d.ellipse((5,8,18,19),fill=col); d.ellipse((16,3,28,15),fill=tuple(min(255,c+30) for c in col))
 else:
  d.polygon([(5,23),(11,8),(20,5),(27,21),(17,28)],fill=col,outline=(207,204,192)); d.point((16,15),fill=(231,226,216))
 im.save(IC/f'{name}.png')

# Reusable dark-fantasy button panel for the in-game UI.
panel=Image.new('RGBA',(160,56),(0,0,0,0)); d=ImageDraw.Draw(panel)
d.rectangle((1,1,158,54),fill=(25,31,34,244),outline=(178,145,91,255),width=2)
d.rectangle((4,4,155,51),outline=(94,113,103,255),width=1)
d.line((7,6,152,6),fill=(215,185,128,255),width=1)
d.line((7,49,152,49),fill=(52,66,64,255),width=1)
for x in (4,153):
    for y in (4,49):
        d.rectangle((x,y,x+2,y+2),fill=(225,197,136,255))
panel.save(UI/'button_panel.png')

# App icon preview copy
if not (ROOT/'app_icon.png').exists() and (SPR/'app_icon.png').exists(): shutil.copy2(SPR/'app_icon.png',ROOT/'app_icon.png')
print('Assets created:', len(list(ROOT.rglob('*.png'))))
