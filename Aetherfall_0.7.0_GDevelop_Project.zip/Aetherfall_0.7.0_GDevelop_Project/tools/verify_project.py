#!/usr/bin/env python3
"""Static checks for Aetherfall 0.7.0; not a GDevelop editor or Android device test."""
from pathlib import Path
import json, sys
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
errors=[]; notes=[]
def check(ok,msg): (notes if ok else errors).append(msg)
def read_json(path):
    try:return json.loads(path.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'JSON error {path.relative_to(ROOT)}: {e}'); return None
project=read_json(ROOT/'game.json'); data=read_json(ROOT/'data/game_data_0_6.json')
if project and data:
    props=project.get('properties',{})
    check(project.get('firstLayout')=='Main','First layout = Main')
    check(any(x.get('name')=='Main' for x in project.get('layouts',[])),'Main layout exists')
    check(props.get('packageName')=='com.aetherfall.echoeswild','Android package ID preserved')
    check(props.get('orientation')=='landscape' and props.get('scaleMode')=='nearest','Landscape / nearest-neighbour pixel scaling')
    check(props.get('version')=='0.7.0','GDevelop project version = 0.7.0')
    objects=project.get('objects',[]); names=[o.get('name') for o in objects]
    check(len(names)==len(set(names)),'Object names are unique')
    resources=project.get('resources',{}).get('resources',[]); files=[r.get('file') for r in resources if r.get('kind')=='image']
    check(len(files)==len(set(files)),'Image resources are unique')
    missing=[f for f in files if not (ROOT/f).is_file()]
    check(not missing,f'All {len(files)} registered image resources exist'+(f'; missing {missing[:4]}' if missing else ''))
    pngs=sorted(x.relative_to(ROOT).as_posix() for x in (ROOT/'assets').rglob('*.png'))
    check(set(pngs)==set(files),'Registered image resources match files under assets/')
    frames=[fr.get('image') for o in objects for a in o.get('animations',[]) for dr in a.get('directions',[]) for fr in dr.get('sprites',[])]
    check(not [f for f in frames if f not in set(files)],'Every sprite frame references a registered image')
    check(all(e.get('sprite') in set(names) for e in data.get('enemies',{}).values()),'Every enemy definition has a GDevelop Sprite object')
    themes=sorted({r['theme'] for r in data.get('regions',[])})
    check(all('Bg_'+t in set(names) for t in themes),'All unique map themes have a background sprite')
    check(all('Bg'+l+'_'+t in set(names) for t in themes for l in ['Far','Mid','Front']),'All map themes have 3 parallax sprites')
    check(all('Icon_'+s in set(names) for s in data.get('equipment_slots',[])),'Equipment icons exist')
    check(all('Hero_'+k in set(names) for k in ['warrior','mage','archer','rogue']),'Four class-specific hero sprite objects exist')
    check(len(data.get('regions',[]))>=31,'31 named location entries are configured')
    check(len(data.get('settlements',[]))>=3 and {x['name'] for x in data['settlements']} >= {'Krosstoen','Hill Town','Elmort'},'Three named settlements are recorded separately')
    check(all(len(r.get('segments',[]))>=5 and r['length']>=7500 for r in data['regions'] if r['type'] not in ('event_hub',)),'Long maps have five authored route segments and >7,500 px length')
    check(all(r.get('source_confidence') and r.get('reference_note') for r in data['regions']),'Every location has a provenance/confidence note')
    check(any(len(r.get('bosses',[]))>=2 for r in data['regions']),'A multi-boss location is configured')
    cls=data.get('classes',{})
    check(set(cls)=={'warrior','mage','archer','rogue'},'Four Darkrise-inspired classes are configured')
    check(all(len(c.get('skills',{}))==3 and c.get('basic_attack',{}).get('range',0)>0 for c in cls.values()),'Each class has its own basic attack and three skills')
    check(len({tuple(c['skills'][k]['name'] for k in ['arc_bolt','shadow_dash','whirlwind']) for c in cls.values()})==4,'Each class has a distinct skill kit')
    prog=data.get('progression',{}); xp=prog.get('xp_required_by_level',[])
    check(prog.get('max_level')==200 and len(xp)==200 and xp[-1]==0 and all(isinstance(v,int) and v>0 for v in xp[:-1]),'A complete 1–200 EXP table exists')
    check(abs(xp[35]-70000)<=1000,'Level 36 EXP requirement is approximately 70,000')
    check(xp[137]==10500000,'Level 138 observation anchor = 10,500,000')
    check(all(xp[i]<xp[i+1] for i in range(178)),'EXP thresholds increase monotonically from Lv.1 through Lv.179')
    check('not a claim' in prog.get('xp_curve_metadata',{}).get('high_level_patch_context',''),'High-level 50% patch note is not misread as an adjacent-level drop')
    check(sum(xp[:179])==2_000_000_000 and sum(xp[189:199])==5_000_000_000,'Cumulative XP calibration targets = 2B / 5B')
    check('NOT_OFFICIAL' in str(prog.get('xp_table_source','')),'EXP table is explicitly marked estimate, not official Darkrise data')
    check(len(prog.get('xp_map_index_by_level',[]))==200 and len(prog.get('xp_target_kills_by_level',[]))==200,'EXP map / target-kill calibration spans 200 levels')
    check(all(0<=i<len(data['regions']) for i in prog.get('xp_map_index_by_level',[])),'Every level references an existing farming map')
    check(data.get('save',{}).get('schema_version')==9 and len(prog.get('xp_migration_tables',{}).get('schema8',[]))==200,'Save schema 9 preserves schema-8 XP migration table')
    check(len(data.get('enemies',{}))>=26 and all(b in data['enemies'] for r in data['regions'] for b in (r.get('bosses') or ([r['boss']] if r.get('boss') else []))),'All named boss definitions exist')
    check(len(data.get('quests',[]))>=11,'Quest chain remains present')
    layouts=project.get('layouts',[]); events=layouts[0].get('events',[]) if layouts else []
    code='\n'.join(e.get('inlineCode','') for e in events if e.get('type')=='BuiltinCommonInstructions::JsCode')
    check(len(code)>50000 and '__AETHERFALL_DATA__' not in code,'Embedded runtime is generated with serialized data')
    for token,label in [('renderClasses','Class selection page'),('Hero_'+"'"+'+(p.classId','Class-specific hero rendering'),('regionPage','Paginated map browser'),('schemaVersion: 9','Schema 9 profile'),('bosses||','Multi-boss support'),('group.forEach','Tiled long-map parallax')]:
        check(token in code,label+' is present')
    check('31 địa điểm' in code,'Lobby advertises expanded map count')
# Decode all graphics, including class sprite variants.
all_pngs=list((ROOT/'assets').rglob('*.png')); bad=[]
for f in all_pngs:
    try:
        with Image.open(f) as im: im.verify()
    except Exception as e: bad.append(f'{f.relative_to(ROOT)}: {e}')
check(not bad,f'All {len(all_pngs)} PNG files decode'+(f'; failures {bad[:3]}' if bad else ''))
if errors:
    print('FAILED static checks:')
    for e in errors: print(' -',e)
    print('\nPassed:',len(notes))
    sys.exit(1)
print('PASS static checks:')
for n in notes: print(' -',n)
print('\nNOTE: static checks only; GDevelop editor preview and Android APK/device test are not included.')
