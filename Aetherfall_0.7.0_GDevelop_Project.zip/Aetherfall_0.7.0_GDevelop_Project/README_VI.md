# Aetherfall 0.7.0 — GDevelop project

Bản nâng cấp tập trung vào ba yêu cầu còn thiếu ở 0.6.x: **bản đồ dài và nhiều địa danh hơn, bốn nghề nhân vật, và đường cong EXP được chỉnh lại theo mốc Lv.36**.

## Thay đổi chính
- Mở rộng từ 8 khu vực tự đặt thành **31 mục địa điểm có tên tham chiếu Darkrise**, gồm tuyến campaign, event và challenge. Đây là danh mục đã nghiên cứu được, **không phải toàn bộ khoảng 100 địa điểm** mà phần mô tả cửa hàng Darkrise nhắc đến.
- Tách ba thị trấn **Krosstoen, Hill Town, Elmort** thành settlement; không trộn thị trấn với map chiến đấu.
- Các map chiến đấu có chiều dài thiết kế **7.600–13.600 px**, chia 5 đoạn tuyến, có landmark và 14–30 quái rải dọc đường. Nền parallax được lặp ngang để không lộ khoảng trống ở các map dài.
- Thêm bốn nghề **Warrior, Mage, Archer, Rogue**; mỗi nghề có bộ chỉ số, tầm đánh, tốc độ, chí mạng, đòn đánh thường và ba kỹ năng riêng. Có thể đổi nghề tại sảnh.
- Bổ sung roster boss có tên riêng ở các dungeon/late-game map, gồm Exiled King, Skeleton King, Glacial Swine, Infernax, Mutant Rat và Ashen Reaper.
- Đường cong EXP 1–200 được cân chỉnh lại: Lv.36 cần 70.000 EXP để lên Lv.37; giữ mốc quan sát tạm tính Lv.138 = 10.500.000 EXP và các tổng mục tiêu 2B / 5B.
- Nâng save schema lên 9; migration giữ phần trăm thanh EXP của schema 8.

## Chạy kiểm tra
```bash
node --check scripts/runtime_event.js
node tests/mock_gdevelop_smoke.js
python tools/verify_project.py
```

## Tái tạo project sau khi sửa dữ liệu/runtime
```bash
python build_project.py
node --check scripts/runtime_event.js
node tests/mock_gdevelop_smoke.js
python tools/verify_project.py
```

## Giới hạn cần biết
- Các chiều dài map, mốc mở khóa đầu game, số lượng quái, vị trí landmark và một số map đầu game là **thiết kế Aetherfall**, không phải số đo trực tiếp từ Darkrise.
- Tên map có ghi `source_confidence`; các địa danh chỉ được nhắc trong guide/cộng đồng không được gắn nhãn như patch note chính thức.
- Bộ sprite nghề hiện là biến thể bảng màu từ sprite gốc trong dự án; chưa phải bốn bộ hoạt họa vẽ tay hoàn toàn khác nhau.
- Boss có tên gốc đã được thêm vào roster; một số đang dùng lại khung AI/hoạt họa boss có sẵn, chưa phải toàn bộ bộ chiêu và animation được tái tạo chính xác.
- Đã chạy kiểm tra tĩnh, kiểm tra cú pháp JavaScript và mock-runtime. **Chưa mở GDevelop Editor Preview, chưa build APK, chưa cài/kiểm tra trên điện thoại thật.**

## Tài liệu
- `docs/CHANGELOG_0.7.0_VI.md`
- `docs/AETHERFALL_0.7.0_SPEC_VI.md`
- `docs/DARKRISE_MAP_INDEX_0.7.0.csv`
- `docs/XP_CURVE_0.7.0.csv`
- `XP_BALANCE_NOTES_VI.md`
