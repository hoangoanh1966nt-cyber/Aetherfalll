# Checklist phát hành Aetherfall 0.7.0

> Chỉ đánh dấu mục sau khi kiểm tra thực tế. PASS từ mock/unit test không thay thế GDevelop Preview hoặc Android device test.

## Project và cấu hình
- [ ] `game.json` mở thành công trong phiên bản GDevelop mục tiêu.
- [ ] Scene `Main` chạy bằng GDevelop Preview, không có lỗi event/resource.
- [ ] App name, package ID `com.aetherfall.echoeswild`, version `0.7.0`, icon và landscape đúng.
- [ ] Bốn trang map browser hiện đủ 31 địa điểm tham chiếu; ba town Krosstoen/Hill Town/Elmort được ghi riêng.
- [ ] Mỗi map load đúng background và ba lớp parallax, không để khoảng trống nền khi chạy tới cuối map.
- [ ] Bố cục phù hợp màn 16:9/20:9, notch và safe area.

## Nghề, cấp độ, EXP và tiến trình
- [ ] Chọn/đổi được Warrior, Mage, Archer, Rogue; save giữ nghề sau khi tắt/mở.
- [ ] Đòn đánh thường có tầm, tốc độ và sát thương khác nhau theo nghề.
- [ ] Ba kỹ năng mỗi nghề hoạt động, MP/cooldown/unlock level chính xác.
- [ ] Gate campaign cần đủ cấp và clear địa điểm campaign trước; event/challenge dùng gate riêng; Forest of Wished yêu cầu hoàn thành Bridge of Stagnation.
- [ ] XP Lv.36 = 70.000; kiểm tra bảng ở Lv.1, 10, 20, 35, 36, 56, 80, 100, 129, 130, 138, 180 và 199.
- [ ] EXP quái theo roster map; boss nhận EXP và gear theo cấu hình riêng; map cũ bị giảm EXP khi farm vượt cấp.
- [ ] Save schema 8 migrate sang schema 9, giữ level/XP bar/inventory/quest/equipment/checkpoint.

## Gameplay, map và AI
- [ ] Map dài 7.600–13.600 px được chơi từ đầu tới cuối; camera và parallax không giật/hở nền.
- [ ] 14–30 quái rải suốt tuyến; quái off-screen không gây lag khi map dài.
- [ ] Named boss: Exiled King, Skeleton King, Glacial Swine, Infernax, Desecrated Demon, Mutant Rat và Ashen Reaper.
- [ ] Tower of Insanity có Mutant Rat và Ashen Reaper cùng spawn theo thứ tự/độ khó dự kiến.
- [ ] Projectile pooling, boss phase, chết/hồi sinh, pause và đổi map không crash.
- [ ] Inventory, required level, cường hóa +20, potion/food/buff/checkpoint/nhiệm vụ vẫn hoạt động.
- [ ] Điều khiển đa chạm không xung đột di chuyển/tấn công/kỹ năng.

## Android runtime và phát hành
- [ ] Cài APK trên Android thật, mở icon vào màn chọn hồ sơ.
- [ ] VN-01/VN-02/AS-01 lưu độc lập; save tồn tại sau force-stop và mở lại.
- [ ] Chơi qua các map đầu, giữa, cuối game và event/challenge; kiểm tra boss ở từng nhánh.
- [ ] Đo FPS, RAM, nhiệt độ, pin, dung lượng tải và độ ổn định trong phiên chơi dài.
- [ ] Kiểm tra âm thanh, orientation, safe area và touch trên nhiều tỉ lệ màn hình.
- [ ] APK test cài được; AAB/signing được quản lý riêng khi phát hành Google Play.

## Trạng thái tại source handoff 0.7.0
- 44 static checks, Node syntax check và mock-runtime tests: PASS (xem `TEST_REPORT_0.7.0_VI.md`).
- GDevelop Editor/Preview, Android build, signing, installation và real-device test: **CHƯA KIỂM TRA**.
