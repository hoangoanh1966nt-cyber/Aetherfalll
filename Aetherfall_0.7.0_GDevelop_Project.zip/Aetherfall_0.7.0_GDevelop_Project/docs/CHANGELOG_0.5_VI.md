# Aetherfall 0.5.0 — Changelog

Ngày: 18/11/2026

## Mở rộng thế giới
- Mở rộng bản đồ từ 5 lên 8 khu vực.
- Thêm Băng Nguyên Vĩnh Cửu (Lv.35), Miệng Núi Lửa Tro Đỏ (Lv.45) và Tháp Sao Sụp Đổ (Lv.56).
- Ngưỡng mở khu vực hiện là Lv.1 / 5 / 11 / 18 / 26 / 35 / 45 / 56; mỗi vùng đều cần clear vùng trước.
- Bổ sung background riêng, ba lớp parallax và roster quái cho ba vùng mới.

## Quái và boss
- Thêm Frost Howler, Crystal Guardian, Ember Hound, Cinder Mage, Ash Golem, Star Reaver và Astral Seraph.
- Thêm ba boss: Glacier Colossus, Ember Drake và Astral Archon.
- Tạo sprite riêng và nhóm animation Idle/Move/Telegraph/Attack cho các sinh vật mới.

## Tiến trình và phần thưởng
- Thay XP curve tăng theo cấp số nhân 1.34 bằng đường cong bậc hai có kiểm soát.
- XP yêu cầu tăng theo level nhưng không còn nhảy lên hơn một triệu cho một cấp ở Lv.35.
- Thêm hệ số EXP khu vực tăng từ ×1.0 ở R1 đến ×20.0 ở R8 cho quái/boss.
- Hiển thị lượng EXP thực nhận trong thông báo phần thưởng.
- Migration save schema 5 giữ dữ liệu tiến trình cũ và quy đổi EXP dư theo curve mới.

## Sửa lỗi và kiểm tra
- Bổ sung các hàm chọn, trang bị, cường hóa và bán vật phẩm còn thiếu trong runtime inventory.
- Sửa kiểm tra gate và cập nhật hiển thị bản đồ 8 vùng.
- Thêm mock tests cho gate không đồng đều, XP curve, region XP scaling, AI và boss attacks.
- Chưa phải APK: GDevelop Preview và Android device test chưa thực hiện.
