# Aetherfall 0.6.0 — Changelog

## Tiến trình nhân vật và EXP
- Thêm giới hạn cấp nhân vật Lv.200.
- Chuyển EXP yêu cầu mỗi cấp thành bảng dữ liệu trung tâm 1–200; giữ nguyên đường cong cân bằng Aetherfall 0.5 để tránh thay đổi tiến độ ngoài ý muốn khi chưa có bảng Darkrise đáng tin cậy.
- Lv.200 là cấp tối đa, không phát sinh level-up tràn.
- Thêm khu vực thông tin nhân vật trong Túi Trang Bị: level, EXP hiện tại / EXP yêu cầu và thanh tiến độ.
- Màn sảnh cũng hiển thị tiến trình EXP theo định dạng có dấu phân tách hàng nghìn.
- Nâng save schema lên 6, giữ hồ sơ cũ và chuẩn hóa level không vượt quá 200.

## Nghiên cứu Darkrise
- Thêm `data/darkrise_xp_research_0_6.json` với 200 dòng level.
- Lv.138 ghi nhận mốc quan sát xấp xỉ 10.5M EXP yêu cầu; các level chưa đo vẫn để `null`.
- Không dùng dữ liệu ước tính/cộng đồng thay cho số liệu Darkrise chính thức.
- Tách rõ EXP cân bằng Aetherfall khỏi dữ liệu tham chiếu Darkrise.

## Giới hạn xác minh
- Static checks và Node mock tests có thể chạy trong gói.
- Chưa mở project bằng GDevelop Editor, chưa chạy Preview trên GDevelop thật và chưa build/cài APK.
