# AETHERFALL: ECHOES OF THE WILD — ĐẶC TẢ PHÁT TRIỂN 0.4

**Trạng thái:** Đã chốt theo xác nhận của người chơi ngày 18/11/2026.  
**Phạm vi:** RPG chuyên sâu, ưu tiên nền tảng gameplay hoàn chỉnh và tương thích Android.  
**Quy tắc mở khu vực:** BẮT BUỘC đạt cấp nhân vật tối thiểu; không cho vào sớm.

## 1. Quyết định nền tảng và công cụ

- **Engine chính đề xuất:** GDevelop. Dựng scene, event, điều khiển cảm ứng, giao diện, gameplay và quy trình xuất Android.
- **Pixel Studio:** tạo/chỉnh sprite sheet nhân vật, quái, boss, vật phẩm, tileset và animation.
- **Pydroid 3:** công cụ Python phụ trợ để sinh/kiểm tra JSON, mô phỏng cân bằng, tính sát thương, XP, tỷ lệ rơi đồ. Không dùng Pydroid làm runtime của APK cuối.
- **ChatGPT + AI Helper trong engine:** hỗ trợ đặc tả, viết event/logic, tạo prompt, rà lỗi và kiểm thử theo checklist. AI không được là phụ thuộc bắt buộc khi chơi; AI quái chạy offline bằng state machine/behavior logic.
- Không duy trì đồng thời hai engine gameplay chính. Không thể tự động chuyển file Pygame `.py` thành project GDevelop; phải tái dựng scene/event và tái sử dụng dữ liệu/tài nguyên phù hợp.

## 2. Cấp độ và quyền truy cập khu vực

| Khu vực | Level tối thiểu | Điều kiện mở |
|---|---:|---|
| 1. Rừng Thì Thầm | 1 | Mở từ đầu |
| 2. Tàn Tích Rêu Phủ | 5 | Hoàn thành khu vực trước và đạt Lv.5 |
| 3. Đầm Lầy Ánh Trăng | 10 | Hoàn thành khu vực trước và đạt Lv.10 |
| 4. Rễ Cây Hư Không | 15 | Hoàn thành khu vực trước và đạt Lv.15 |
| 5. Thánh Điện Cổ Thụ | 20 | Hoàn thành khu vực trước và đạt Lv.20 |

- Điều kiện cấp là bắt buộc. Nút khu vực chưa đủ cấp phải bị khóa và hiển thị rõ `Cần Lv.X`.
- Điều kiện hoàn thành khu vực trước vẫn được giữ; chỉ đạt cấp không tự mở khóa nội dung chưa hoàn thành.
- Kiểm tra điều kiện cả ở giao diện chọn khu vực lẫn hàm bắt đầu màn để tránh lách khóa.

## 3. Trang bị và đánh giá tổng thể

Mỗi vật phẩm trang bị cần có tối thiểu:
- `item_level`: cấp của món đồ.
- `required_level`: cấp nhân vật tối thiểu để trang bị; mặc định bằng `item_level`.
- `rarity`: Common, Uncommon, Rare, Epic, Legendary.
- `slot`: weapon, armor, ring (có thể mở rộng sau).
- Chỉ số cơ bản: ATK, DEF, HP; có thể thêm tốc độ đánh, chí mạng, kháng nguyên tố khi hệ thống cân bằng đã sẵn sàng.
- `gear_score`: điểm đánh giá riêng của món đồ, tính nhất quán từ cấp, phẩm chất, chỉ số và cường hóa.

Yêu cầu:
- Chỉ số phải tăng theo item level và phẩm chất; không chỉ đổi nhãn cấp mà chỉ số giữ nguyên.
- Nhân vật chỉ được mặc khi `player_level >= required_level`. Nếu không đủ cấp, nút trang bị bị khóa và giải thích lý do.
- Có Gear Score từng món và tổng Gear Score toàn bộ trang bị đang mặc.
- Túi đồ hiển thị phẩm chất, item level, required level, Gear Score và chỉ số.
- Khi chọn món để so sánh, hiển thị chênh lệch xanh/đỏ so với món đang mặc.
- Cường hóa vẫn tăng chỉ số nhưng không được bỏ qua điều kiện cấp mặc đồ.
- Cần xử lý dữ liệu save cũ: bổ sung trường còn thiếu bằng migration mặc định, không làm mất trang bị/tiến trình.

## 4. HP, MP, cấp độ và kỹ năng

- Lên cấp: tăng chỉ số tối đa theo cấu hình và hồi đầy HP + MP.
- MP hiển thị rõ trên HUD, có hồi phục theo thời gian; kỹ năng tiêu hao MP.
- Mỗi kỹ năng có: cấp mở khóa, tiêu hao MP, sát thương/hiệu ứng, tầm, thời gian thi triển, hồi chiêu và phản hồi UI.
- Hồi chiêu phải hiển thị dạng vòng/đếm số trên nút cảm ứng; không thể kích hoạt khi chưa hồi xong hoặc thiếu MP.
- Tách thời gian hồi chiêu khỏi animation để không bị reset khi chuyển scene.
- Có thể mở rộng cây kỹ năng và nâng cấp kỹ năng ở các bản sau, nhưng 0.3 phải đảm bảo các kỹ năng hiện có hoạt động ổn định.

## 5. Nhiệm vụ

Xây hệ thống nhiệm vụ dữ liệu hóa, không hard-code một nhiệm vụ duy nhất:
- Loại: tiêu diệt, thu thập, khám phá/đến vị trí, đánh boss, nói chuyện NPC.
- Trạng thái: locked, available, active, completed, rewarded.
- Mỗi nhiệm vụ có ID, yêu cầu, tiến độ, điều kiện nhận, điều kiện hoàn thành, XP/vàng/vật phẩm thưởng.
- Có nhật ký nhiệm vụ, mục tiêu đang theo dõi trên HUD và cập nhật tiến độ khi sự kiện gameplay xảy ra.
- NPC giao/trả nhiệm vụ; không trao thưởng hai lần.
- Có nhiệm vụ chính theo chương và nhiệm vụ phụ; 0.3 ưu tiên khung hệ thống và một bộ nhiệm vụ mẫu đủ để kiểm chứng.

## 6. AI quái vật

AI offline theo state machine, có thể mở rộng behavior:
- Idle/patrol → detect → chase/approach → telegraph → attack → recover → return/patrol.
- Các archetype khác nhau: cận chiến nhanh, tanker, pháp sư tầm xa, bay/bổ nhào, phục kích, quái dưới nước.
- Quái cần giới hạn vùng hoạt động, xử lý địa hình, khoảng cách tấn công, cooldown, hướng nhìn và trạng thái bị đánh.
- Boss có nhiều phase, bộ chiêu riêng, dấu hiệu báo đòn dễ đọc và điểm yếu/nhịp phản công.
- Không gọi API AI trực tuyến trong combat; đảm bảo offline, ít độ trễ và chi phí vận hành bằng 0.

## 7. Bình thuốc, thức ăn và buff

### Bình thuốc
- Nhiều cấp bình HP/MP, hiệu quả hồi cố định hoặc theo % tối đa, số lượng trong túi và cooldown dùng.
- Có thể bổ sung thuốc giải độc/trạng thái xấu.
- Không cho dùng vượt quá HP/MP tối đa; hiển thị lượng hồi thực tế.

### Thức ăn
- Có nhiều nhóm: thịt nướng, cá nướng, súp nấm, trái cây/thảo mộc và món đặc biệt theo vùng.
- Phẩm chất: Common, Uncommon, Rare, Epic, Legendary.
- Phẩm chất ảnh hưởng cường độ buff và/hoặc thời lượng; cùng món ăn có hiệu ứng nền nhất quán.
- Buff có thời hạn, icon và bộ đếm trên HUD; quy tắc cộng dồn rõ ràng (mặc định không cộng dồn cùng loại, dùng món mới thay thế thời hạn/hiệu lực theo luật đã định).
- Không để thức ăn thay thế hoàn toàn bình thuốc trong chiến đấu; cân bằng riêng hồi tức thời và buff dài hạn.

## 8. Chết, hồi sinh, checkpoint và oxy

- Có làng/thị trấn làm điểm hồi sinh chính và checkpoint phụ đã kích hoạt.
- Khi chết trên cạn: hồi sinh tại điểm an toàn gần nhất đã kích hoạt; không hồi sinh ở vị trí nguy hiểm.
- Khi ở dưới nước: có thanh oxy; oxy giảm theo thời gian, có nguồn bổ sung/điểm ngoi lên. Khi oxy về 0, nhân vật chịu sát thương theo nhịp.
- Nếu chết dưới nước, hồi sinh tại checkpoint/địa điểm an toàn gần nhất trên mặt đất hoặc thị trấn, không ở dưới nước.
- Quy định mất gì khi chết phải minh bạch; mặc định không xóa trang bị/XP đã nhận, có thể mất một phần vàng nếu sau này người chơi duyệt cân bằng đó. 0.3 không tự ý phạt mất vật phẩm quý.
- Có thời gian bất tử ngắn sau hồi sinh để tránh chết lặp.

## 9. Đa dạng quái và nội dung

Mục tiêu mở rộng ít nhất 8 archetype quái thường, mỗi nhóm có silhouette, animation, chỉ số và hành vi phân biệt; boss có sprite/animation/phase riêng. Không tính đổi màu cùng một sprite là một loại quái mới.

## 10. Đồ họa và animation

- Nhân vật: idle, run, jump/fall, land, attack, cast, hurt, dodge, death.
- Quái: idle, move, telegraph, attack, hurt, death; boss có phase/skill riêng.
- Vật phẩm: icon riêng cho vũ khí, giáp, nhẫn, nguyên liệu, bình thuốc, thức ăn.
- Mỗi vùng có tileset, background nhiều lớp, props, ánh sáng/màu sắc và vật thể tương tác riêng.
- Kỹ năng có VFX, projectile/impact và feedback trúng đòn.
- Tài nguyên phải có kích thước, pivot, frame rate, naming convention và giấy phép sử dụng được ghi nhận.
- Ảnh concept không được tính là tài nguyên gameplay đã tích hợp.

## 11. Tiêu chuẩn kiểm thử trước APK

- Không lỗi cú pháp/event; không crash khi vào/thoát khu vực, mở túi, trang bị, chết/hồi sinh, lưu/tải.
- Thử khóa level ở cả UI và logic; thử trang bị dưới cấp và đúng cấp.
- Kiểm tra Gear Score tính lại sau mặc/tháo/cường hóa.
- Kiểm tra nhiệm vụ không nhận/trả thưởng hai lần.
- Kiểm tra HP/MP, potion, food buff, cooldown, oxygen và respawn.
- Kiểm tra AI không kẹt địa hình/vượt khỏi khu vực và boss chuyển phase đúng.
- Kiểm tra điều khiển đa chạm, nhiều tỷ lệ màn hình, FPS, bộ nhớ, âm thanh và save offline trên Android thật.
- Chỉ gọi là APK hoàn thành khi đã build ra file APK, cài đặt và chạy thử được trên thiết bị Android.

## 12. Thứ tự triển khai

1. Thiết lập project GDevelop và quy ước dữ liệu/asset; giữ bản Pygame 0.2 làm prototype tham chiếu.
2. Xây hệ thống level khu vực + save migration.
3. Xây item level, required level, Gear Score, so sánh trang bị.
4. Xây nhiệm vụ data-driven.
5. Xây consumables, food quality/buffs, oxygen, town/checkpoint/respawn.
6. Hoàn thiện AI và archetype quái.
7. Tích hợp sprite/tileset/animation/VFX/audio.
8. Kiểm thử, tối ưu và đóng gói APK Android.

## 13. Nguyên tắc không được tự ý thay đổi

- RPG chuyên sâu, không giản lược thành game đánh quái một nút.
- Khu vực bắt buộc đạt level tối thiểu; không có chế độ vào sớm.
- Cấp nhân vật phải >= required level mới được mặc trang bị.
- Có Gear Score và so sánh trang bị.
- Có HP, MP, hồi chiêu, nhiệm vụ, AI quái, thuốc, thức ăn, buff, oxy và hồi sinh an toàn.
- Chọn máy chủ ở màn đầu theo phong cách game mobile; các lựa chọn server hiện tại chỉ là hồ sơ save offline cho tới khi có backend online thực sự.
- Không tuyên bố có multiplayer/server online, APK hoặc tính năng đã hoàn tất nếu chưa triển khai và kiểm thử.


## Phạm vi 0.4 (đợt nâng cấp hiện tại)
- Chỉ nâng cấp đồ họa trình bày, tối ưu hiệu năng hiển thị và AI quái offline.
- Không mở rộng gameplay/tiến trình hoặc thay đổi điều kiện vùng, trang bị, nhiệm vụ và save.
- AI mới vẫn offline và không phụ thuộc API/AI trực tuyến khi chơi.
