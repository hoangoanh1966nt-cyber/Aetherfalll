# Aetherfall 0.6.2 — Nhật ký cập nhật

- Thiết kế lại EXP đầu game theo EXP gốc của quái trên từng bản đồ; Lv.1 giảm từ 352.397 xuống 336 EXP.
- Tính EXP yêu cầu bằng EXP quái trung bình của map × hệ số map × số lượt hạ quái mục tiêu.
- Quái giữ tỷ lệ EXP riêng từ dữ liệu gốc; boss lấy XP riêng của boss, không dùng hệ số thưởng boss cố định.
- Thêm giảm thưởng khi farm bản đồ đã quá thấp cấp.
- Giữ mốc Lv.138 ≈10,5M, tổng ước lượng 2B đến Lv.180 và 5B cho Lv.190–200 làm các điểm neo tham khảo.
- Save schema 7 → 8, giữ nguyên phần trăm tiến độ thanh EXP của save 0.6.1.
- Thêm bảng CSV/JSON cho từng cấp và EXP từng quái/boss theo map.
