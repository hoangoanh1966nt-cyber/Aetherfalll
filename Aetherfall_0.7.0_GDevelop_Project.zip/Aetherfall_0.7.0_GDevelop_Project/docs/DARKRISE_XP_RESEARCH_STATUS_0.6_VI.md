# Kết quả nghiên cứu EXP Darkrise — 18/11/2026

## Kết luận
Nguồn công khai đã tìm được không xuất bản bảng EXP yêu cầu chính thức từng cấp 1–200. Trang Roika công bố ở bản 0.26 rằng EXP yêu cầu lên cấp bị giảm một nửa cho các cấp 130–200; trang patch notes hiện hiển thị v0.27 (14/04/2026), nhưng không kèm bảng số.

Một bài viết cộng đồng tháng 01/2026 kể rằng tổng EXP từ Lv.1 đến Lv.180 khoảng 2 tỷ và riêng Lv.190–200 gần 5 tỷ. Đây chỉ là lời kể tổng hợp, không thể tách thành số EXP cần cho từng level.

## Mốc đang có
- Lv.138: khoảng 10,500,000 EXP yêu cầu để lên cấp tiếp theo; ảnh tham chiếu còn hiển thị khoảng 1,900,000 EXP đã tích lũy.
- Phiên bản Darkrise, độ khó và bản build của ảnh chưa được xác nhận độc lập.

## Bảng ghi nhận 200 cấp
`data/darkrise_xp_research_0_6.json` chứa 200 hàng. Lv.138 giữ giá trị quan sát có nhãn provisional; 199 hàng còn lại chưa có dữ liệu cụ thể nên để null.

## Nguồn
- Roika official patch notes: https://roika.org/
- Darkrise community XP anecdote: https://www.reddit.com/r/darkrisegame/comments/1pyw31u/best_thing_about_the_christmas_event/
- Talk Android guide (mô tả EXP bar, không có bảng numeric): https://www.talkandroid.com/32170-darkrise-pixel-action-rpg-guide/

Không dùng bảng ước lượng Aetherfall để tự nhận là bảng Darkrise. Muốn lấp đầy các dòng còn thiếu, cần đo trực tiếp từ từng màn Character/Inventory trong cùng một phiên bản Darkrise, hoặc trích xuất và xác minh công thức gốc từ bản game.
