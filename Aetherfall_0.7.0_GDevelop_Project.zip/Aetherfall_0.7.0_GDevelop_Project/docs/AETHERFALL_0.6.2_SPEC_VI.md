# Aetherfall 0.6.2 — Đặc tả EXP

1. Ngưỡng EXP mỗi cấp dựa trên EXP gốc trung bình của roster quái thuộc bản đồ hiện tại và số quái dự kiến cần hạ.
2. EXP từng quái tỷ lệ theo trường `xp` của chính quái đó. Không ép mọi quái trong map nhận cùng EXP.
3. EXP boss dùng trường `xp` gốc của boss; tỷ lệ boss/quái thay đổi đúng theo dữ liệu từng boss.
4. `progression.xp_target_kills_by_level` lưu số lượt hạ quái thường mục tiêu cho từng cấp.
5. `progression.xp_required_by_level` lưu ngưỡng 200 cấp. Lv.200 có ngưỡng 0.
6. Mốc Lv.138≈10,5M, tổng 2B đến Lv.180 và 5B từ Lv.190–200 được dùng làm điểm neo ước lượng, không phải số liệu công bố chính thức.
7. Save schema 8 chuyển phần trăm EXP từ schema 7 bằng bảng cũ được lưu trong `xp_migration_tables`.
