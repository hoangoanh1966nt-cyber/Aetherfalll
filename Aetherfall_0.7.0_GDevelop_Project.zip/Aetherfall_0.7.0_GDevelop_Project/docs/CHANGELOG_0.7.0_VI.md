# Aetherfall 0.7.0 — Đại tu map, nghề và EXP

## Đã triển khai trong project
- Mở rộng danh mục từ 8 vùng tự đặt thành 31 địa điểm tham chiếu, phân nhóm campaign/event/challenge và đánh dấu độ tin cậy nguồn.
- Tách Krosstoen, Hill Town và Elmort thành settlement riêng.
- 27 địa điểm tuyến chính có dữ liệu route; các địa điểm event/challenge có nhánh truy cập riêng.
- Tất cả map chiến đấu trong bản này dài 7.600–13.600 px theo thiết kế Aetherfall; 5 đoạn tuyến, landmark, 14–30 quái rải từ đầu đến gần cuối map.
- Lặp 7 tile parallax mỗi lớp nền để bao phủ chiều ngang map; tạo bộ palette background/parallax riêng theo từng địa điểm.
- Thêm chọn nghề Warrior/Mage/Archer/Rogue, lưu nghề vào profile, có nút đổi nghề ở sảnh, chỉ số/đòn đánh/3 kỹ năng khác nhau.
- Sinh 4 bộ sprite nhân vật 24 frame/nghề từ sprite hiện có bằng biến thể palette; chưa phải animation vẽ mới.
- Thêm boss có tên Exiled King, Skeleton King, Glacial Swine, Infernax, Desecrated Demon, Mutant Rat, Ashen Reaper; Tower of Insanity spawn hai boss.
- Chỉnh bảng EXP 1–200, Lv.36=70.000 EXP, Lv.138=10.500.000 EXP, tổng 2B và 5B làm neo tham khảo; giữ ngưỡng tăng đều qua Lv.130 và không diễn giải sai mức giảm 50% so với bảng trước bản vá.
- Save schema 9 và giữ bảng EXP schema 8 để đổi tỷ lệ tiến độ thanh EXP khi migration.
- Cập nhật smoke test và kiểm tra tĩnh cho cấu trúc mới.

## Độ chính xác / giới hạn
- Store description của Darkrise nói tới khoảng 100 địa điểm; project hiện mới catalog 31 địa danh có tài liệu tham chiếu, không tự nhận đã có đủ 100.
- Một số tên map đầu và vị trí trong tiến trình chỉ được guide/cộng đồng nhắc đến; không khẳng định thứ tự/gate là dữ liệu chính thức.
- Kích thước pixel, vị trí quái, landmark, số đợt quái và palette của từng map là thiết kế mới của Aetherfall. Chưa đo bằng gameplay capture từng map Darkrise.
- Một số boss đang tái sử dụng template chiến đấu/animation boss hiện có trong Aetherfall.
- Chưa được kiểm thử bằng GDevelop Editor Preview, chưa build APK, chưa cài trên Android thật.
