# Aetherfall 0.6.0 — Đặc tả tiến trình nhân vật và EXP

## 1. Trần level
- Level tối đa: 200.
- Level 200 không cần EXP cho cấp kế tiếp và không tăng vượt cap.
- Các chỉ số HP/MP vẫn tăng theo từng lần level-up như logic hiện tại.

## 2. Bảng EXP của Aetherfall
- Dùng `data/game_data_0_6.json` → `progression.xp_required_by_level`.
- Có đúng 200 phần tử: index 0 ứng với level 1; level 199 cần EXP để lên level 200; level 200 là `null` vì đã đạt cap.
- Đường cong hiện tại được giữ nguyên từ Aetherfall 0.5 để không phá cân bằng đã test.
- Đây là đường cong cân bằng RIÊNG CỦA AETHERFALL, không phải bảng EXP Darkrise.

## 3. Màn Character/Inventory
Màn Túi Trang Bị hiển thị:
- Level hiện tại / 200.
- EXP hiện tại / EXP cần để lên cấp tiếp theo.
- Thanh tiến độ EXP.
- Khi đạt Lv.200 hiển thị trạng thái MAX LEVEL.

Màn sảnh cũng hiển thị level và EXP hiện tại.

## 4. Nghiên cứu Darkrise riêng biệt
- Bảng `data/darkrise_xp_research_0_6.json` có 200 hàng level.
- Mốc Lv.138 khoảng 10.5M EXP để lên cấp tiếp được ghi là quan sát tạm thời; phiên bản game của ảnh chưa xác minh.
- Các mốc chưa đo để `null`, không được dùng công thức Aetherfall thay thế rồi gắn nhãn Darkrise.

## 5. Tương thích save
- Save schema tăng lên 6.
- Giữ dữ liệu level, EXP, đồ, nhiệm vụ, khu vực đã vượt qua và ba hồ sơ offline.
- Nếu save cũ có level trên 200 thì đưa về 200; không để phát sinh level-up vượt cap.
