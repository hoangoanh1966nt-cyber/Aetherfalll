# Báo cáo kiểm tra Aetherfall 0.6.1

Ngày chạy: 18/11/2026

## PASS — kiểm tra trong môi trường hiện tại
- `python build_project.py`: tái tạo `game.json` từ dữ liệu trung tâm và runtime template.
- `python tools/verify_project.py`: xác thực cấu trúc project, dữ liệu EXP 1–200, các ràng buộc tổng EXP, tám vùng, save schema, hiển thị EXP và tài nguyên.
- `node --check scripts/runtime_event.js`: cú pháp JavaScript hợp lệ.
- `node tests/mock_gdevelop_smoke.js`: kiểm tra đường cong 200 cấp, mốc Lv.138, điểm gãy Lv.130, tổng 2B/Lv.180 và 5B/Lv.190–200; EXP quái/boss theo bản đồ; EXP nhiệm vụ; migration save; các vùng mở khóa; AI, boss, projectile, inventory và giới hạn Lv.200.
- 557/557 ảnh PNG giải mã được; 24 lớp parallax có kích thước nhất quán.

## Chưa kiểm tra — không được xem là PASS
- Chưa mở `game.json` bằng GDevelop Editor thật hoặc chạy Preview trong GDevelop.
- Chưa đo FPS/RAM/nhiệt độ/pin trên Android thật.
- Chưa kiểm thử cảm ứng đa điểm, notch/safe area và vòng đời app trên thiết bị.
- Chưa xuất APK/AAB, ký, cài đặt hoặc chạy trên điện thoại.

Các bài test PASS ở trên là kiểm tra tĩnh và Node mock tests; chúng không thay thế GDevelop runtime hoặc kiểm thử Android.
