# Aetherfall 0.6.2 — Báo cáo kiểm thử

## Kết quả
- PASS: kiểm tra cấu trúc GDevelop project; 557 ảnh PNG, sprite references và parallax assets.
- PASS: Node syntax check cho runtime JavaScript.
- PASS: test mock GDevelop — lưu/đọc hồ sơ, save migration schema 6/7, các cổng 8 bản đồ, hệ EXP 200 cấp và giới hạn Lv.200.
- PASS: kiểm tra ngưỡng đầu game: Lv.1=336 EXP, Lv.2=357 EXP, Lv.5=404 EXP.
- PASS: EXP trung bình của roster quái ở cấp mở khóa mỗi map khớp số lượt hạ quái mục tiêu.
- PASS: quái cùng map có XP khác nhau theo XP gốc; boss nhận XP theo tỷ lệ XP boss gốc.
- PASS: tổng EXP Lv.1–179 = 2.000.000.000; Lv.138=10.500.000; Lv.190–199=5.000.000.000.

## Chưa thực hiện
- Chưa mở GDevelop Editor/Preview thật trong phiên này.
- Chưa build APK Android, chưa cài và kiểm tra trên thiết bị thật.

Các PASS ở trên là kiểm tra tĩnh và mock-runtime; không thay thế kiểm thử thiết bị Android thực tế.
