# Aetherfall 0.7.0 — Báo cáo kiểm thử

## PASS — những gì đã chạy trong môi trường hiện tại

### 44 kiểm tra tĩnh
- Main layout / first layout và cấu hình landscape, nearest-neighbour, package ID.
- Tên object/resource không trùng; 777 resource ảnh được đăng ký và tồn tại.
- 777 PNG giải mã thành công; mọi sprite frame trỏ tới resource tồn tại.
- 31 map theme có background và đủ ba lớp parallax.
- Bốn object hero class tồn tại; 31 location entry và 3 settlement.
- Map combat có 5 đoạn tuyến, độ dài trên 7.500 px; ghi chú confidence nguồn.
- Multi-boss Tower of Insanity; named boss definitions tồn tại.
- Bốn nghề có đòn đánh và ba kỹ năng riêng.
- Bảng EXP 200 cấp, các anchor Lv.36/Lv.138, tổng mục tiêu 2B/5B và cờ ghi rõ là estimate.
- XP map/target-kill index đủ 200 level; schema 9 giữ migration table schema 8.
- Runtime đã nhúng dữ liệu và có class screen, map pagination, tiled parallax.

### Mock-runtime tests
- Khởi tạo runtime và mở lobby.
- Hiển thị 4 nghề; kiểm tra thông số tầm đánh Warrior/Mage/Archer có tác động đến đòn đánh cơ bản.
- Hiển thị danh mục 31 địa điểm; kiểm tra các tên map, settlement, độ dài, 5 segments và confidence label.
- Kiểm tra gate campaign, event, challenge và Forest of Wished.
- Kiểm tra quái phân bố trên phần lớn chiều dài; kiểm tra các named boss và 2 boss Tower of Insanity.
- Kiểm tra XP Lv.36=70.000, Lv.138=10.500.000, tổng 2B/5B, EXP tăng đều qua Lv.130 và metadata ghi rõ mốc giảm 50% so với đường cong trước bản vá, migration schema 8.
- Kiểm tra chuyển trang map, mở class screen, vào Slime Field và load theme riêng.

## CHƯA KIỂM THỬ
- Không mở được GDevelop Editor Preview trong lượt này.
- Không có APK/AAB được build trong lượt này.
- Chưa cài hoặc chạy trên điện thoại Android thật.
- Chưa đo FPS/RAM/nhiệt độ/pin trên thiết bị thật.

**Kết luận:** project source và mock runtime đã qua các kiểm tra có thể chạy tự động trong môi trường này; chưa thể kết luận game đã chạy ổn định trên Android cho tới khi GDevelop Preview và APK thật được kiểm tra.
