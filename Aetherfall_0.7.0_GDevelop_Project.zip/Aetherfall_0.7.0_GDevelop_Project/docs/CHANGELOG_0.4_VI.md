# Aetherfall 0.4.0 — Changelog

## Đồ họa
- Bổ sung 15 lớp ảnh parallax cho 5 vùng; camera cuộn tạo độ sâu ba lớp.
- Làm mới HUD trận đấu: panel thông tin, meter HP/MP/oxy và thanh HP boss.
- Thêm hiệu ứng orb projectile cho đòn tầm xa của quái.

## Hiệu năng
- Tái sử dụng pool UI text/panel; không xóa/đặt lại toàn bộ UI trước mỗi frame.
- Culling sprite quái nằm ngoài viewport; chỉ tạo sprite khi cần hiển thị.
- Cache animation index, facing và kích thước sprite; chỉ cập nhật khi thay đổi.
- Animation của sprite không hiển thị được tắt cập nhật nền.
- Projectile visual được pool và tái sử dụng.

## AI quái offline
- Pháp sư giữ khoảng cách, nhắm vị trí dự đoán nhẹ và bắn đạn bay có thể né.
- Quái phục kích/lao tới, quái bay bổ nhào, quái độc có cú lunge, tanker báo đòn nặng.
- Quái có leash và quay về vị trí gốc nếu người chơi kéo chúng quá xa.
- Boss duy trì hai pha; pha hai xen kẽ đòn quét và đạn rễ.

## Không thay đổi
- Không thêm chương, khu vực, loại trang bị, nhiệm vụ hay cơ chế tiến trình mới.
- Giữ các điều kiện level gate, hệ thống trang bị, nhiệm vụ, save profile, kỹ năng, consumables và sinh tồn của 0.3.
- Giữ package ID để không đổi danh tính ứng dụng; version tăng lên 0.4.0.

## Ghi chú xác minh
Kiểm tra cú pháp, cấu trúc và mock smoke test không thay thế GDevelop Preview hoặc đo hiệu năng Android thật. APK chưa được build trong môi trường này.
