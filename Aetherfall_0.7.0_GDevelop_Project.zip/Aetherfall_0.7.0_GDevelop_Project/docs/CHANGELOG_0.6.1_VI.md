# Aetherfall 0.6.1 — Nhật ký cập nhật

- Thiết lập bảng EXP cân bằng riêng cho Lv.1–200 theo các mốc tham khảo Darkrise.
- Tổng EXP ước lượng để đạt Lv.180: 2.000.000.000; mốc Lv.138: 10.500.000; tổng Lv.190–200: 5.000.000.000.
- Thể hiện điểm gãy ở Lv.130 theo ghi chú chính thức Darkrise v0.26 giảm một nửa EXP yêu cầu ở Lv.130–200.
- Tính EXP quái/boss theo EXP cần ở cấp hiện tại, vùng bản đồ, trọng số kẻ địch và độ phù hợp cấp; nhiệm vụ cũng co giãn theo cấp.
- Bổ sung mô tả rõ dữ liệu ước lượng và tệp nghiên cứu nguồn trong `research/`.
- Chuyển save schema 6 sang 7, giữ cấp, trang bị, nhiệm vụ và tỷ lệ tiến độ thanh EXP.

Đây là bản cân bằng Aetherfall lấy cảm hứng từ Darkrise, không phải bản chép số liệu chính thức của Darkrise.
