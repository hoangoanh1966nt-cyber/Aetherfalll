# Aetherfall 0.7.0 — Đặc tả build

## 1. Danh mục địa điểm
- 31 entry có tên tham chiếu Darkrise trong `data/game_data_0_6.json`.
- 27 entry trên tuyến campaign; nhánh event/challenge nằm ngoài tuyến mở khóa tuyến tính.
- Ba settlement riêng: Krosstoen, Hill Town, Elmort.
- UI map browser phân trang 8 địa điểm/trang.
- Map combat dài 7.600–13.600 px, 5 segment, 4 landmark, 14–30 quái; boss đặt cuối tuyến.
- Forest of Wished mở sau khi vượt Bridge of Stagnation; map event/challenge kiểm tra gate riêng.
- Mỗi entry có `source_confidence`, `reference_note`, `level_gate_verified`, `enemy_level_min/max` để không nhầm level do thiết kế với số đã được patch note xác nhận.

## 2. Nghề nhân vật
| Nghề | Vai trò | Đòn đánh thường | Kỹ năng |
|---|---|---|---|
| Warrior | Cận chiến, HP/DEF cao | Tầm 118, damage scale 1.16 | Blade Throw, Shield Charge, Ground Slam |
| Mage | Phép thuật, tầm xa | Tầm 305, damage scale 1.02 | Fireball, Blink, Frost Storm |
| Archer | Đánh xa, tầm tối đa | Tầm 390, damage scale 0.93 | Piercing Arrow, Backstep, Rain of Arrows |
| Rogue | Cận chiến nhanh, chí mạng | Tầm 132, damage scale 1.12 | Shuriken Throw, Shadow Step, Dance of Blades |

Nghề được lưu trong profile. Người chơi có thể đổi tại sảnh; hiệu lực lên chỉ số, tốc độ, tầm đánh và kỹ năng. Sprite mỗi nghề là palette variant của animation hiện có.

## 3. EXP
- XP table 200 cấp; Lv.36→37=70.000 EXP.
- Lv.138→139=10.500.000 EXP (anchor tạm tính).
- Sum `xp_required_by_level[0:179]` = 2.000.000.000; sum `[189:199]` = 5.000.000.000.
- EXP thresholds increase monotonically across Lv.129→130. The official 50% high-level patch note is relative to the pre-patch Lv.130–200 curve, not to adjacent Lv.129.
- Reward by monster and boss uses each map's roster, source XP weights, target kills and overlevel decay.
- Values are Aetherfall estimates, not extracted Darkrise data.

## 4. Migration
- Save schema 9.
- Migrates schema 6, 7, 8 while preserving profile level, inventory, quests, gear and XP bar percentage where source table exists.

## 5. Validation status
- 41+ static project checks pass.
- Node syntax check passes.
- Mock GDevelop runtime smoke test passes for map catalog, classes, progression gates, long-map spawns, named bosses, XP anchors and save migration.
- GDevelop Editor Preview / Android packaging / real-device test: not done.
