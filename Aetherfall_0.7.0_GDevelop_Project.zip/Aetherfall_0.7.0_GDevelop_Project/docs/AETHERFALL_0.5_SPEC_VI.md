# Aetherfall 0.5.0 — Đặc tả mở rộng khu vực và EXP

## 1. Khu vực và level gate

| Vùng | Tên | Level tối thiểu | Hệ số EXP quái | Boss cuối vùng |
|---:|---|---:|---:|---|
| 1 | Rừng Thì Thầm | 1 | ×1.0 | — |
| 2 | Tàn Tích Rêu Phủ | 5 | ×1.8 | — |
| 3 | Đầm Lầy Ánh Trăng | 11 | ×3.2 | — |
| 4 | Rễ Cây Hư Không | 18 | ×5.2 | — |
| 5 | Thánh Điện Cổ Thụ | 26 | ×8.0 | Cổ Thụ Hộ Vệ |
| 6 | Băng Nguyên Vĩnh Cửu | 35 | ×11.5 | Cự Thần Băng Vĩnh Cửu |
| 7 | Miệng Núi Lửa Tro Đỏ | 45 | ×15.5 | Hỏa Long Tro Đỏ |
| 8 | Tháp Sao Sụp Đổ | 56 | ×20.0 | Giáo Chủ Tinh Giới |

Điều kiện vào vùng gồm cả hai điều kiện: level nhân vật đạt `min_level` của chính vùng đó và đã hoàn thành vùng liền trước. Runtime `canEnterRegion()` kiểm tra lại điều kiện khi bắt đầu, không chỉ khóa nút ở UI.

## 2. Công thức EXP mỗi cấp

Với cấp hiện tại L, đặt `n = max(0, L - 1)`:

`EXP cần để lên cấp = ceil(80 + 14n + 5n²)`

Một số ngưỡng:

| Cấp | EXP cần |
|---:|---:|
| 1 | 80 |
| 2 | 99 |
| 5 | 216 |
| 10 | 611 |
| 11 | 720 |
| 18 | 1,763 |
| 26 | 3,555 |
| 35 | 6,336 |
| 45 | 10,376 |
| 56 | 15,975 |

Ngưỡng vẫn tăng theo cấp nhưng không tăng theo cấp số nhân 1.34 như công thức cũ. Việc tải save cũ giữ lại level/EXP và tự quy đổi phần EXP vượt ngưỡng theo đường cong 0.5.

## 3. EXP rơi từ quái

`EXP nhận = round(EXP cơ bản của quái × hệ số EXP khu vực)`.

Ví dụ cùng quái Trùng Bò Hư Không có EXP nền 66:
- Rễ Cây Hư Không: round(66 × 5.2) = 343 EXP.
- Tháp Sao Sụp Đổ: round(66 × 20.0) = 1,320 EXP.

Boss cũng áp dụng hệ số khu vực. Ví dụ Giáo Chủ Tinh Giới: 2,200 × 20 = 44,000 EXP. Thông báo sau khi hạ quái/boss hiển thị lượng EXP thực nhận, kể cả khi có rơi trang bị.

### EXP ước tính mỗi lần clear toàn bộ quái

Các số dưới đây là tổng gần đúng nếu hạ hết quái thường và boss trong một lượt, trước khi cộng EXP nhiệm vụ:

| Vùng | EXP mỗi lượt clear ước tính |
|---:|---:|
| 1 | 200 |
| 2 | 440 |
| 3 | 1,351 |
| 4 | 2,246 |
| 5 | 5,376 |
| 6 | 21,310 |
| 7 | 39,449 |
| 8 | 61,420 |

Số clear thực tế còn phụ thuộc nhiệm vụ, cách người chơi đánh, có tiêu diệt đủ quái hay không và phần thưởng khác; đây là ước tính cân bằng từ roster và số lượng spawn hiện tại, không phải cam kết thời gian lên cấp.

## 4. Nội dung khu vực mới

- **Băng Nguyên Vĩnh Cửu:** Sói Tru Băng Giá (phục kích nhanh), Hộ Vệ Tinh Thể (tanker), Linh Hồn Nguyệt; boss Cự Thần Băng Vĩnh Cửu có bắn băng ở pha 2.
- **Miệng Núi Lửa Tro Đỏ:** Khuyển Tro Đỏ (phục kích), Thuật Sĩ Tro Tàn (đánh xa), Thạch Nhân Dung Nham (đòn nện); boss Hỏa Long Tro Đỏ lao lửa ở pha 2.
- **Tháp Sao Sụp Đổ:** Kẻ Cướp Sao (phục kích), Thiên Sứ Tinh Tú (đánh xa trên không), Trùng Bò Hư Không; boss Giáo Chủ Tinh Giới bắn loạt đạn hư không ở pha 2.

Mỗi archetype mới có sprite riêng và bốn animation: Idle, Move, Telegraph, Attack; mỗi animation có sáu frame. Các vùng mới có background riêng và ba lớp parallax.

## 5. Save và tương thích

- Save schema hiện tại: 5.
- Giữ ba hồ sơ offline, level, EXP, inventory, equipped items, nhiệm vụ, checkpoint và danh sách vùng đã clear.
- Các vùng cũ được giữ nguyên index 0–4; ba vùng mới nối tiếp index 5–7.
- Chưa có tài khoản trực tuyến, multiplayer hoặc đồng bộ cloud save.
